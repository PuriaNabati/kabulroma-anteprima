<?php
defined('ABSPATH') || exit;

// Poste Delivery Web Business, official national list, April 2026, net of VAT.
// https://business.poste.it/business/files/1476572722522/pdw-prezzi-spedizioni-nazionali.pdf
function kr_poste_base_cost($kg) {
    foreach (array(1=>4.63, 2=>4.84, 3=>5.49, 5=>5.98, 10=>8.52, 15=>9.59, 20=>10.08, 25=>12.13, 30=>12.13, 40=>23.20, 50=>26.48, 70=>32.54) as $limit=>$price) {
        if ($kg > 0 && $kg <= $limit + 0.000001) return $price;
    }
    return null;
}
function kr_poste_weight($contents) {
    $kg = 0; $missing = false;
    foreach ($contents as $item) {
        $p = $item['data'] ?? false;
        if (!$p || !$p->needs_shipping() || empty($item['quantity'])) continue;
        $parent_id = $p->get_parent_id() ?: $p->get_id();
        // Standard parcel service is not a refrigerated transport service.
        if (has_term(array('carne','surgelati','latticini'), 'product_cat', $parent_id)) { $missing = true; continue; }
        $weight = (float) $p->get_weight();
        $item_kg = $weight > 0 ? (float) wc_get_weight($weight, 'kg') : 0;
        // Legacy variations have an explicit weight attribute but no numeric weight field.
        if ($item_kg <= 0 && $p->is_type('variation')) {
            foreach ($p->get_attributes() as $name=>$value) {
                if (preg_match('/peso|weight|formato/i', $name)) $item_kg = kr_attribute_grams((string) $value) / 1000;
                if ($item_kg > 0) break;
            }
        }
        if ($item_kg <= 0) { $missing = true; continue; }
        $kg += $item_kg * (int) $item['quantity'];
    }
    return array('products'=>$kg, 'missing'=>$missing, 'total'=>$kg + max(0, (float) get_option('kr_poste_packaging_g', 0)) / 1000);
}
add_filter('woocommerce_package_rates', function ($rates, $package) {
    if (!get_option('kr_poste_enabled') || ($package['destination']['country'] ?? '') !== 'IT') return $rates;
    // This replaces the old per-item flat rate for Italy only. Other destinations stay unchanged.
    $keep = array_filter($rates, function ($rate) { return $rate->get_method_id() === 'local_pickup'; });
    $weight = kr_poste_weight($package['contents']);
    $postcode = preg_replace('/\s/', '', $package['destination']['postcode'] ?? '');
    $base = kr_poste_base_cost($weight['total']);
    $trepalle = $postcode === '23030' && stripos($package['destination']['city'] ?? '', 'trepalle') !== false;
    if ($weight['missing'] || $base === null || in_array($postcode, array('23041','22061'), true) || $trepalle) return $keep;
    // Pickup from the shop + delivery to the customer's address. Both explicitly requested.
    $gross = round(($base + 0.82 + (get_option('kr_poste_pickup', 1) ? 0.82 : 0)) * 1.22, 2);
    // Preserve the shop's own shipping tax treatment; never add VAT twice to the public amount.
    $tax_rates = WC_Tax::get_shipping_tax_rates();
    $taxes = wc_tax_enabled() && !WC()->customer->get_is_vat_exempt() ? WC_Tax::calc_tax($gross, $tax_rates, true) : array();
    $rate = new WC_Shipping_Rate('kr_poste_weight', 'Poste Italiane — consegna a domicilio', $gross - array_sum($taxes), $taxes, 'kr_poste_weight');
    $rate->add_meta_data('Peso prodotti (kg)', wc_format_decimal($weight['products'], 3));
    $rate->add_meta_data('Imballaggio (g)', max(0, (float) get_option('kr_poste_packaging_g', 0)));
    $keep[$rate->get_id()] = $rate;
    return $keep;
}, 100, 2);
function kr_poste_weight_row() {
    if (!get_option('kr_poste_enabled') || !WC()->cart) return;
    $w = kr_poste_weight(WC()->cart->get_cart());
    echo '<tr class="kr-weight"><th>Peso prodotti</th><td data-title="Peso prodotti">' . ($w['missing'] ? 'Da verificare con il negozio' : esc_html(number_format_i18n($w['products'], 3) . ' kg')) . '</td></tr>';
    if (!$w['missing'] && $w['total'] > $w['products']) echo '<tr class="kr-weight"><th>Peso con imballaggio</th><td>' . esc_html(number_format_i18n($w['total'], 3) . ' kg') . '</td></tr>';
}
add_action('woocommerce_review_order_before_shipping', 'kr_poste_weight_row');
add_action('woocommerce_cart_totals_before_shipping', 'kr_poste_weight_row');
add_filter('woocommerce_no_shipping_available_html', function ($html) {
    return get_option('kr_poste_enabled') ? 'Per questo carrello o indirizzo la spedizione va concordata con il negozio. Contattaci prima di pagare.' : $html;
});
add_filter('woocommerce_cart_no_shipping_available_html', function ($html) {
    return get_option('kr_poste_enabled') ? 'Per questo carrello o indirizzo la spedizione va concordata con il negozio.' : $html;
});
add_action('admin_menu', function () {
    add_submenu_page('woocommerce', 'Spedizioni Kabul Roma', 'Spedizioni Kabul Roma', 'manage_woocommerce', 'kr-poste', function () {
        if (!current_user_can('manage_woocommerce')) return;
        if (isset($_POST['kr_poste_save'])) {
            check_admin_referer('kr_poste_settings');
            update_option('kr_poste_packaging_g', max(0, (float) wc_format_decimal(wp_unslash($_POST['packaging_g'] ?? 0))));
            update_option('kr_poste_pickup', !empty($_POST['pickup']));
            update_option('kr_poste_enabled', !empty($_POST['enabled']));
            WC_Cache_Helper::get_transient_version('shipping', true);
            echo '<div class="notice notice-success"><p>Impostazioni aggiornate.</p></div>';
        }
        echo '<div class="wrap"><h1>Spedizioni Kabul Roma — Poste Italiane</h1><p>Poste Delivery Web Business, listino nazionale aprile 2026. Consegna a domicilio inclusa nel calcolo. Il ritiro costa 0,82 € + IVA per pacco. Nessuna etichetta viene acquistata automaticamente.</p><p>Valido per pacchi non voluminosi in Italia, fino a 70 kg, salvo destinazioni escluse. I prodotti senza peso non ricevono una tariffa automatica. Inserire nei prodotti il peso della confezione completa, non il volume in ml.</p><form method="post">';
        wp_nonce_field('kr_poste_settings');
        echo '<p><label><input type="checkbox" name="enabled" value="1" ' . checked(get_option('kr_poste_enabled'), true, false) . '> Attiva spedizione Poste in base al peso (Italia)</label></p><p><label>Peso aggiuntivo di scatola e imballaggio (grammi) <input type="number" name="packaging_g" min="0" step="1" value="' . esc_attr(get_option('kr_poste_packaging_g', 0)) . '"></label></p><p><label><input type="checkbox" name="pickup" value="1" ' . checked(get_option('kr_poste_pickup', 1), true, false) . '> Ritiro in negozio da parte di Poste</label></p><p>Con 0 grammi il calcolo usa soltanto i pesi salvati dei prodotti. Verificare il peso reale dell’imballaggio prima delle spedizioni.</p>';
        submit_button('Salva impostazioni', 'primary', 'kr_poste_save');
        echo '</form><table class="widefat striped"><thead><tr><th>Peso massimo</th><th>Prezzo base, IVA esclusa</th></tr></thead><tbody>';
        foreach (array(1,2,3,5,10,15,20,25,30,40,50,70) as $limit) echo '<tr><td>' . esc_html($limit . ' kg') . '</td><td>' . esc_html(number_format_i18n(kr_poste_base_cost($limit),2) . ' €') . '</td></tr>';
        echo '</tbody></table><p><a target="_blank" rel="noopener" href="https://business.poste.it/business/files/1476572722522/pdw-prezzi-spedizioni-nazionali.pdf">Tariffario ufficiale Poste</a></p></div>';
    });
});
