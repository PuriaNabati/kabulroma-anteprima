<?php
defined('ABSPATH') || exit;
function kr_checkout_locale() { if(get_option('kr_vetrina_live'))switch_to_locale('it_IT'); }
add_action('woocommerce_checkout_update_order_review','kr_checkout_locale',0);
add_action('woocommerce_before_checkout_process','kr_checkout_locale',0);
add_action('woocommerce_before_checkout_form', function () {
    if (!kr_commerce_enabled()) return;
    // The old theme moves the complete payment form above the address. Restore native placement.
    foreach (array('woocommerce_checkout_before_customer_details','woocommerce_checkout_after_customer_details','woocommerce_checkout_order_review') as $hook) {
        while (($priority = has_action($hook, 'woocommerce_checkout_payment')) !== false) remove_action($hook, 'woocommerce_checkout_payment', $priority);
    }
    add_action('woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20);
}, 9999);
add_filter('woocommerce_checkout_fields', function ($fields) {
    if (!kr_commerce_enabled() && !(defined('WOOCOMMERCE_CHECKOUT') && WOOCOMMERCE_CHECKOUT)) return $fields;
    $order = array('email','first_name','last_name','phone','country','address_1','postcode','city','state','address_2','company');
    foreach ($order as $i=>$name) if (isset($fields['billing']['billing_'.$name])) $fields['billing']['billing_'.$name]['priority'] = 10 + $i*10;
    $labels = array('email'=>'Email','first_name'=>'Nome','last_name'=>'Cognome','phone'=>'Telefono','country'=>'Paese','address_1'=>'Via e numero civico','postcode'=>'CAP','city'=>'Città','state'=>'Provincia','address_2'=>'Interno, scala o citofono','company'=>'Azienda');
    foreach ($labels as $name=>$label) if (isset($fields['billing']['billing_'.$name])) $fields['billing']['billing_'.$name]['label'] = $label;
    foreach (array('email','phone','country','address_1','address_2','company','state') as $name) if(isset($fields['billing']['billing_'.$name])) $fields['billing']['billing_'.$name]['class'] = array('form-row-wide');
    foreach (array('first_name','postcode') as $name) if(isset($fields['billing']['billing_'.$name])) $fields['billing']['billing_'.$name]['class'] = array('form-row-first');
    foreach (array('last_name','city') as $name) if(isset($fields['billing']['billing_'.$name])) $fields['billing']['billing_'.$name]['class'] = array('form-row-last');
    if(isset($fields['billing']['billing_phone'])) $fields['billing']['billing_phone']['autocomplete']='tel';
    if(isset($fields['billing']['billing_email'])) $fields['billing']['billing_email']['autocomplete']='email';
    return $fields;
}, 9999);
add_filter('woocommerce_ship_to_different_address_checked', function($checked){return kr_commerce_enabled()?false:$checked;});
add_filter('gettext', function($translated,$text,$domain){
    if($domain==='woocommerce' && kr_commerce_enabled()) {
        if($text==='Billing details')return 'I tuoi dati';
        if($text==='Ship to a different address?')return 'Consegna a un altro indirizzo';
    }
    return $translated;
},20,3);
add_filter('woocommerce_form_field',function($html,$key){return kr_commerce_enabled() && $key==='billing_country'?'<h3 class="kr-address-title">Indirizzo di consegna</h3>'.$html:$html;},20,2);
add_filter('woocommerce_order_button_text',function($text){return kr_commerce_enabled()?'Paga e conferma l’ordine':$text;});
add_action('woocommerce_checkout_order_review',function(){if(kr_commerce_enabled())echo '<h3 class="kr-payment-title">Pagamento</h3>';},15);
add_filter('woocommerce_cart_item_name',function($name,$item){
    if(!is_checkout() || !get_option('kr_vetrina_live'))return $name;
    $p=$item['data'];$img=$p->get_image('woocommerce_thumbnail',array('width'=>56,'height'=>56,'alt'=>'','loading'=>'lazy'));
    return '<span class="kr-review-product">'.$img.'<span class="kr-review-name">'.$name.'</span></span>';
},20,2);
function kr_display_grams($kg) {return $kg>=1?number_format_i18n($kg, $kg==floor($kg)?0:3).' kg':number_format_i18n($kg*1000,0).' g';}
add_filter('woocommerce_checkout_cart_item_quantity',function($html,$item,$key){
    if(!kr_commerce_enabled())return $html;
    $q=(int)$item['quantity'];$kg=kr_poste_product_kg($item['data']);$max=$item['data']->get_max_purchase_quantity();if($max<1)$max=99;
    $weight=$kg>0?'<small class="kr-line-weight">'.esc_html(kr_display_grams($kg).' × '.$q.' = '.kr_display_grams($kg*$q)).'</small>':'';
    return '<div class="kr-review-controls"><div class="kr-qty"><button type="button" data-kr-qty="-1" aria-label="Diminuisci quantità">−</button><input class="kr-checkout-qty" type="number" min="1" max="'.esc_attr($max).'" name="kr_qty['.esc_attr($key).']" value="'.esc_attr($q).'" aria-label="Quantità '.esc_attr(wp_strip_all_tags($item['data']->get_name())).'"><button type="button" data-kr-qty="1" aria-label="Aumenta quantità">+</button></div><a class="kr-remove" href="'.esc_url(wc_get_cart_remove_url($key)).'">Rimuovi</a></div>'.$weight;
},20,3);
add_action('woocommerce_checkout_update_order_review',function($posted){
    if(!get_option('kr_vetrina_live'))return;parse_str(wp_unslash($posted),$data);
    foreach((array)($data['kr_qty']??array()) as$key=>$quantity){
        $item=WC()->cart->get_cart_item($key);if(!$item)continue;$q=max(1,min(99,absint($quantity)));if($q===(int)$item['quantity'])continue;
        $p=$item['data'];$max=$p->get_max_purchase_quantity();
        if(!$p->is_in_stock()||!$p->has_enough_stock($q)||($max>0&&$q>$max)||!apply_filters('woocommerce_update_cart_validation',true,$key,$item,$q)){wc_add_notice('Quantità non disponibile per '.wp_strip_all_tags($p->get_name()).'.','error');continue;}
        WC()->cart->set_quantity($key,$q,false);
    }
},10);
