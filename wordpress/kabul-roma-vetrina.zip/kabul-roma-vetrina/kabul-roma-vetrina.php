<?php
/**
 * Plugin Name: Kabul Roma Vetrina
 * Description: Vetrina Kabul Roma con catalogo, carrello e checkout WooCommerce. Attivazione pubblica separata dall'installazione.
 * Version: 1.4.1
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/poste-shipping.php';
require_once __DIR__ . '/checkout-ux.php';

function kr_seed() {
    static $data;
    if (!$data) $data = json_decode(file_get_contents(__DIR__ . '/catalogo.json'), true);
    return $data;
}
function kr_map() { return (array) get_option('kr_vetrina_map', array()); }
function kr_asset($path) {
    if (strpos($path, 'img/') === 0) {
        $size = substr($path, -4) === '.png' ? 720 : 640;
        $optimized = 'optimized/' . pathinfo($path, PATHINFO_FILENAME) . '-' . $size . '.webp';
        if (file_exists(__DIR__ . '/assets/' . $optimized)) return plugins_url('assets/' . $optimized, __FILE__);
        return kr_original_photo($path);
    }
    return plugins_url('assets/' . ltrim($path, '/'), __FILE__);
}
function kr_original_photo($path) {
    $assets = (array) get_option('kr_vetrina_assets', array());
    if (!empty($assets[$path])) return wp_get_attachment_url($assets[$path]);
    return 'https://purianabati.github.io/kabulroma-anteprima/img/' . rawurlencode(basename($path));
}
function kr_import_photo($path, $parent = 0, $description = '') {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $assets = (array) get_option('kr_vetrina_assets', array());
    if (!empty($assets[$path]) && get_post($assets[$path])) return (int) $assets[$path];
    $url = 'https://purianabati.github.io/kabulroma-anteprima/img/' . rawurlencode(basename($path));
    $tmp = download_url($url, 45);
    if (is_wp_error($tmp)) throw new RuntimeException($tmp->get_error_message());
    $attachment = media_handle_sideload(array('name' => basename($path), 'tmp_name' => $tmp), $parent, $description);
    if (is_wp_error($attachment)) { @unlink($tmp); throw new RuntimeException($attachment->get_error_message()); }
    $assets[$path] = (int) $attachment;
    update_option('kr_vetrina_assets', $assets, false);
    if ($description) update_post_meta($attachment, '_wp_attachment_image_alt', $description);
    return (int) $attachment;
}
function kr_import_promos() {
    foreach (array('online-albicocche-secche', 'online-pistacchio-salato', 'online-pistacchio-salato-con-zafferano', 'online-pistacchio-semplice', 'online-uvetta-verde', 'online-zereshk', 'ahmad-tea-cardamom-500g') as $name) kr_import_photo('img/' . $name . '-cutout.png');
}
function kr_product_id($index, $seed) {
    $map = kr_map();
    return !empty($seed['wc_id']) ? absint($seed['wc_id']) : absint($map[$index] ?? 0);
}
function kr_size($grams) {
    return !$grams ? 'Unico' : ($grams >= 1000 ? ($grams / 1000) . ' kg' : $grams . ' g');
}
function kr_attribute_grams($attributes) {
    $text = str_replace(array('-', '_', ','), array(' ', ' ', '.'), strtolower($attributes));
    if (preg_match('/([0-9]+(?:\.[0-9]+)?)\s*(kg|gr|g|kilo)\b/', $text, $match)) return (float) $match[1] * (in_array($match[2], array('kg', 'kilo'), true) ? 1000 : 1);
    return is_numeric(trim($text)) ? (float) $text : 0;
}
function kr_live_data() {
    $data = kr_seed();
    foreach ($data['prodotti'] as $index => &$item) {
        $item['promo_img'] = kr_asset(preg_replace('/\.jpg$/', '-cutout.png', $item['img']));
        $stem = pathinfo($item['img'], PATHINFO_FILENAME);
        $item['img_srcset'] = implode(', ', array_map(function ($size) use ($stem) {
            return plugins_url('assets/optimized/' . $stem . '-' . $size . '.webp', __FILE__) . ' ' . $size . 'w';
        }, array(320, 640))) . ', ' . kr_original_photo($item['img']) . ' 800w';
        $item['img'] = kr_asset($item['img']);
        $id = kr_product_id($index, $item);
        $product = $id ? wc_get_product($id) : false;
        $item['wc_variants'] = array();
        if (!$product || $product->get_status() !== 'publish') {
            $item['online'] = false;
            continue;
        }
        $item['online'] = true;
        $item['stock'] = $product->is_in_stock();
        $item['noprice'] = $product->get_price() === '';
        $item['wc_url'] = get_permalink($id);
        if ($product->is_type('variable')) {
            $available = $product->get_available_variations();
            foreach ($item['v'] as $vi => &$variant) {
                $match = null;
                foreach ($available as $variation) {
                    $child = wc_get_product($variation['variation_id']);
                    $g = $child && $child->get_weight() !== '' ? (float) wc_get_weight($child->get_weight(), 'g') : 0;
                    $attrs = implode(' ', $variation['attributes']);
                    $expected = kr_size($variant[0]);
                    $attribute_g = kr_attribute_grams($attrs);
                    if (($g && abs($g - (float) $variant[0]) < 1) || ($attribute_g && abs($attribute_g - (float) $variant[0]) < 1) || preg_replace('/[^a-z0-9.]/', '', strtolower($attrs)) === preg_replace('/[^a-z0-9.]/', '', strtolower($expected))) {
                        $match = $variation;
                        break;
                    }
                }
                if ($match) {
                    $variant[1] = (float) $match['display_price'];
                    $attrs = array();
                    foreach ($match['attributes'] as $key => $value) $attrs[] = array('attribute' => preg_replace('/^attribute_/', '', $key), 'value' => $value);
                    $item['wc_variants'][$vi] = array('id' => (int) $match['variation_id'], 'variation' => $attrs, 'available' => (bool) $match['is_in_stock']);
                } else $item['wc_variants'][$vi] = array('id' => 0, 'available' => false);
            }
            unset($variant);
        } else {
            foreach ($item['v'] as $vi => &$variant) {
                if(empty($variant[0])) {
                    static $label_weights;
                    if($label_weights===null)$label_weights=(array)json_decode(file_get_contents(__DIR__.'/label-weights.json'),true);
                    $stem=preg_replace('/-(320|640)$/','',pathinfo($item['img'],PATHINFO_FILENAME));
                    if(!empty($label_weights[$stem]))$variant[0]=(float)$label_weights[$stem];
                    elseif((float)$product->get_weight()>0 && !preg_match('/\b\d+(?:[.,]\d+)?\s*(?:ml|cl|l|litri|litro)\b/iu',$item['it']))$variant[0]=(float)wc_get_weight($product->get_weight(),'g');
                }
                $variant[1] = $product->get_price() === '' ? 0 : (float) wc_get_price_to_display($product);
                $item['wc_variants'][$vi] = array('id' => $id, 'variation' => array(), 'available' => $product->is_purchasable() && $product->is_in_stock());
            }
            unset($variant);
        }
    }
    unset($item);
    return $data;
}
function kr_app_route() {
    return !is_admin() && !is_feed() && !is_robots() && !is_trackback() && !is_wc_endpoint_url() && (is_front_page() || is_shop() || is_product() || is_product_category());
}
function kr_app_enabled() {
    return class_exists('WooCommerce') && kr_app_route() && (get_option('kr_vetrina_live') || (isset($_GET['kr_preview']) && current_user_can('manage_woocommerce')));
}
function kr_commerce_enabled() {
    return class_exists('WooCommerce') && !is_admin() && get_option('kr_vetrina_live') && (is_cart() || is_checkout());
}
function kr_shell_enabled() { return kr_app_enabled() || kr_commerce_enabled(); }
// Preserve native WooCommerce/payment hooks while excluding outdated Nest form markup.
add_filter('woocommerce_locate_template', function ($template, $name) {
    if (kr_commerce_enabled() && $name === 'checkout/form-checkout.php') return __DIR__ . '/checkout-form.php';
    if (kr_commerce_enabled() && preg_match('~^(cart|checkout)/~', $name) && strpos(wp_normalize_path($template), '/themes/') !== false) {
        $core = WC()->plugin_path() . '/templates/' . $name;
        if (is_readable($core)) return $core;
    }
    return $template;
}, 99, 2);
// kr_vetrina_asset_isolation: exclude legacy theme dependencies from this storefront.
add_filter('style_loader_tag', function ($html, $handle, $href) {
    if (kr_shell_enabled() && preg_match('~/plugins/(nest-addons|elementor|revslider)/~', $href)) return '';
    return $html;
}, 999, 3);
add_filter('script_loader_tag', function ($html, $handle, $src) {
    if (kr_shell_enabled() && preg_match('~/plugins/(nest-addons|elementor|revslider)/~', $src)) return '';
    return $html;
}, 999, 3);
add_filter('template_include', function ($template) {
    if (kr_commerce_enabled()) return __DIR__ . '/commerce-template.php';
    return kr_app_enabled() ? __DIR__ . '/template.php' : $template;
}, 99);
add_action('wp', function () {
    if (kr_shell_enabled()) {
        add_filter('show_admin_bar', '__return_false');
        if (kr_commerce_enabled()) switch_to_locale('it_IT');
        if (isset($_GET['kr_preview'])) nocache_headers();
    }
});
add_action('wp_enqueue_scripts', function () {
    if (!kr_shell_enabled()) return;
    global $wp_styles, $wp_scripts;
    foreach ($wp_styles->queue as $handle) {
        $src = $wp_styles->registered[$handle]->src ?? '';
        if (strpos((string) $src, '/themes/') !== false || preg_match('/elementor|nest|revslider/', $handle) || (kr_app_enabled() && preg_match('/woocommerce-layout|woocommerce-general|woocommerce-smallscreen/', $handle))) wp_dequeue_style($handle);
    }
    foreach ($wp_scripts->queue as $handle) {
        $src = $wp_scripts->registered[$handle]->src ?? '';
        if (strpos((string) $src, '/themes/') !== false || preg_match('/^elementor|^revslider|^nest-/', $handle)) wp_dequeue_script($handle);
    }
}, 999);

function kr_import_one($index) {
    $data = kr_seed();
    $seed = $data['prodotti'][$index];
    $map = kr_map();
    $id = kr_product_id($index, $seed);
    $sku = 'KR-CATALOG-' . pathinfo($seed['img'], PATHINFO_FILENAME);
    if (!$id) $id = wc_get_product_id_by_sku($sku);
    $existing = $id ? wc_get_product($id) : false;
    if (!$existing) {
        $variable = count($seed['v']) > 1;
        $product = $variable ? new WC_Product_Variable() : new WC_Product_Simple();
        $product->set_name($seed['it']);
        $product->set_sku($sku);
        $product->set_status('publish');
        $product->set_description($seed['d']['it'] ?? '');
        $product->set_manage_stock(false);
        $product->set_stock_status(!empty($seed['stock']) ? 'instock' : 'outofstock');
        $product->set_tax_status('taxable');
        // No price is invented: unknown prices remain empty and cannot be purchased.
        if (!$variable && empty($seed['noprice'])) $product->set_regular_price((string) $seed['v'][0][1]);
        if (!$variable && !empty($seed['v'][0][0])) $product->set_weight((string) wc_get_weight($seed['v'][0][0], get_option('woocommerce_weight_unit', 'kg'), 'g'));
        $category = null;
        foreach ($data['categorie'] as $cat) if ($cat[0] === $seed['cat']) $category = $cat;
        if ($category) {
            $term = term_exists($category[1], 'product_cat');
            if (!$term) $term = wp_insert_term($category[1], 'product_cat', array('slug' => $category[0]));
            if (!is_wp_error($term)) $product->set_category_ids(array((int) $term['term_id']));
        }
        if ($variable) {
            $attr = new WC_Product_Attribute();
            $attr->set_name('Formato');
            $attr->set_options(array_map(function ($v) { return kr_size($v[0]); }, $seed['v']));
            $attr->set_visible(true);
            $attr->set_variation(true);
            $product->set_attributes(array($attr));
        }
        $id = $product->save();
        if ($variable) {
            foreach ($seed['v'] as $vi => $v) {
                $variation = new WC_Product_Variation();
                $variation->set_parent_id($id);
                $variation->set_attributes(array('formato' => kr_size($v[0])));
                if (empty($seed['noprice'])) $variation->set_regular_price((string) $v[1]);
                $variation->set_stock_status(!empty($seed['stock']) ? 'instock' : 'outofstock');
                if (!empty($v[0])) $variation->set_weight((string) wc_get_weight($v[0], get_option('woocommerce_weight_unit', 'kg'), 'g'));
                $variation->save();
            }
            WC_Product_Variable::sync($id);
        }
        $product->update_meta_data('_kr_catalog_index', $index);
        $product->update_meta_data('_kr_name_fa', $seed['fa'] ?? '');
        $product->update_meta_data('_kr_name_en', $seed['en'] ?? '');
        $product->save();
    }
    $map[$index] = $id;
    update_option('kr_vetrina_map', $map, false);
    if (!get_post_meta($id, '_kr_catalog_photo', true)) {
        $attachment = kr_import_photo($seed['img'], $id, $seed['it']);
        if (!metadata_exists('post', $id, '_kr_previous_image')) update_post_meta($id, '_kr_previous_image', get_post_thumbnail_id($id));
        set_post_thumbnail($id, $attachment);
        update_post_meta($attachment, '_wp_attachment_image_alt', $seed['it']);
        update_post_meta($id, '_kr_catalog_photo', $attachment);
    }
    return $id;
}
add_action('wp_ajax_kr_catalog_import', function () {
    check_ajax_referer('kr_vetrina_admin', 'nonce');
    if (!current_user_can('manage_woocommerce')) wp_send_json_error(array('message' => 'Non autorizzato'), 403);
    $offset = absint($_POST['offset'] ?? 0);
    $count = count(kr_seed()['prodotti']);
    try {
        // Small batches avoid hosting execution limits during image thumbnail generation.
        for ($i = $offset; $i < min($offset + 5, $count); $i++) kr_import_one($i);
        if ($offset + 5 >= $count) kr_import_promos();
        wp_send_json_success(array('next' => min($offset + 5, $count), 'total' => $count));
    } catch (Throwable $e) { wp_send_json_error(array('message' => $e->getMessage(), 'offset' => $i), 500); }
});
add_action('admin_post_kr_vetrina_publish', function () {
    if (!current_user_can('manage_options')) wp_die('Non autorizzato');
    check_admin_referer('kr_vetrina_publish');
    $live = isset($_POST['live']) && $_POST['live'] === '1';
    if ($live && count(kr_map()) < count(kr_seed()['prodotti'])) wp_die('Completare prima l’importazione del catalogo.');
    if (!get_option('kr_vetrina_original')) update_option('kr_vetrina_original', array('theme' => get_stylesheet(), 'front' => get_option('page_on_front'), 'show' => get_option('show_on_front'), 'date' => current_time('mysql')), false);
    update_option('kr_vetrina_live', $live);
    if (function_exists('wp_cache_clear_cache')) wp_cache_clear_cache();
    do_action('litespeed_purge_all');
    wp_safe_redirect(admin_url('themes.php?page=kabul-roma-vetrina'));
    exit;
});
add_action('admin_menu', function () {
    add_theme_page('Kabul Roma Vetrina', 'Kabul Roma Vetrina', 'manage_options', 'kabul-roma-vetrina', 'kr_admin');
});
function kr_admin() {
    $live = (bool) get_option('kr_vetrina_live');
    $total = count(kr_seed()['prodotti']);
    $done = count(kr_map());
    ?>
    <div class="wrap"><h1>Kabul Roma Vetrina</h1>
    <p>La grafica dell’anteprima è collegata a WooCommerce. Il tema precedente, gli ordini, i pagamenti e le impostazioni rimangono disponibili.</p>
    <p><strong>Stato: <?php echo $live ? 'Pubblicata' : 'Anteprima amministratore'; ?></strong></p>
    <p><a class="button" target="_blank" href="<?php echo esc_url(add_query_arg('kr_preview', '1', home_url('/'))); ?>">Apri anteprima sul dominio</a></p>
    <h2>Catalogo e foto</h2><p>I prodotti esistenti conservano prezzi e disponibilità. I nuovi prodotti usano i dati del catalogo approvato; quelli senza prezzo non sono acquistabili. Importazione ripetibile senza duplicati.</p>
    <p id="kr-progress"><?php echo esc_html($done . ' / ' . $total . ' prodotti collegati'); ?></p>
    <button id="kr-import" class="button button-primary">Importa catalogo e foto</button>
    <h2>Pubblicazione</h2><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
    <input type="hidden" name="action" value="kr_vetrina_publish"><input type="hidden" name="live" value="<?php echo $live ? '0' : '1'; ?>"><?php wp_nonce_field('kr_vetrina_publish'); ?>
    <button class="button <?php echo $live ? '' : 'button-primary'; ?>"><?php echo $live ? 'Ripristina la vetrina precedente' : 'Pubblica la nuova vetrina'; ?></button></form></div>
    <script>
    document.getElementById('kr-import').addEventListener('click', async function () {
        this.disabled=true; const out=document.getElementById('kr-progress'); let offset=0;
        try { while(offset<<?php echo (int) $total; ?>) {
            out.textContent='Importazione: '+offset+' / <?php echo (int) $total; ?>';
            const body=new URLSearchParams({action:'kr_catalog_import',nonce:<?php echo wp_json_encode(wp_create_nonce('kr_vetrina_admin')); ?>,offset:String(offset)});
            const response=await fetch(ajaxurl,{method:'POST',credentials:'same-origin',body}); const json=await response.json();
            if(!json.success) throw new Error(json.data.message); offset=json.data.next;
        } out.textContent='Completato: '+offset+' / <?php echo (int) $total; ?>'; }
        catch(error){out.textContent='Interrotto a '+offset+': '+error.message+' — ripremere per riprendere senza duplicati.';}
        this.disabled=false;
    });
    </script>
    <?php
}
