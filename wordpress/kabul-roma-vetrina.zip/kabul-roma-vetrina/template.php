<?php
defined('ABSPATH') || exit;
$data = kr_live_data();
$product_key = null;
if (is_product()) foreach ($data['prodotti'] as $i => $p) if (kr_product_id($i, $p) === get_queried_object_id()) $product_key = 'KR' . str_pad($i + 1, 3, '0', STR_PAD_LEFT);
$config = array('api' => rest_url('wc/store/v1/'), 'checkout' => wc_get_checkout_url(), 'cart' => wc_get_cart_url(), 'preview' => isset($_GET['kr_preview']), 'product' => $product_key);
?><!doctype html>
<html lang="it"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<?php if (isset($_GET['kr_preview'])) echo '<meta name="robots" content="noindex,nofollow">'; ?>
<?php wp_head(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Figtree:wght@400;500;600;700;800&family=Vazirmatn:wght@400;500;700;800&display=swap">
<link rel="stylesheet" href="<?php echo esc_url(kr_asset('app.css')); ?>?v=<?php echo filemtime(__FILE__); ?>">
</head><body><?php wp_body_open(); ?>


<div class="ribbon"><div class="wrap"><span class="tag" data-t="previewTag">Anteprima</span><span data-t="previewMsg">Prodotti e prezzi presi dal sito attuale, da confermare con il negozio.</span></div></div>

<header class="top" id="hdr"><div class="wrap">
  <a class="logo" href="#" id="logoLink" aria-label="Kabul Roma">
    <svg width="44" height="44" viewBox="0 0 44 44" aria-hidden="true">
      <rect width="44" height="44" rx="13" fill="#1d3a8a"/>
      <path d="M11 35V20a11 11 0 0 1 22 0v15" fill="none" stroke="#f2a20c" stroke-width="3.2" stroke-linecap="round"/>
      <path d="M16.5 35V22a5.5 5.5 0 0 1 11 0v13" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"/>
      <circle cx="22" cy="9.5" r="2.2" fill="#f2a20c"/>
    </svg>
    <span class="logo-text">Kabul Roma<small>کابل روما</small></span>
  </a>
  <a class="where" id="whereLink" href="#store">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>
    <span><span data-t="storeIn">Negozio in</span><strong>Via Lamarmora 15</strong></span>
  </a>
  <div class="search" id="searchBox">
    <svg class="ico" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
    <input id="q" type="search" autocomplete="off" role="combobox" aria-expanded="false" aria-controls="suggest" aria-autocomplete="list" aria-label="Cerca" placeholder="Cerca" data-tp="searchPh">
    <button class="clear" type="button" id="qClear" aria-label="Cancella"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
    <div class="suggest" id="suggest" role="listbox"></div>
  </div>
  <div class="lang" role="group" aria-label="Lingua / Language / زبان" id="langSw">
    <span class="ind" aria-hidden="true"></span>
    <button type="button" data-lang="it" aria-pressed="true" title="Italiano">IT</button>
    <button type="button" data-lang="en" aria-pressed="false" title="English">EN</button>
    <button type="button" data-lang="fa" aria-pressed="false" title="فارسی">فا</button>
  </div>
  <button class="cartbtn" id="cartBtn" type="button">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" aria-hidden="true"><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6.2"/><circle cx="10" cy="20.5" r="1.3"/><circle cx="17.5" cy="20.5" r="1.3"/></svg>
    <span class="lbl" data-t="cart">Carrello</span><span class="count" id="cartCount">0</span><span class="sum" id="cartSum" hidden></span>
  </button>
</div></header>

<main class="wrap" id="main">
  <div class="rail" id="rail" role="group" aria-label="Categorie"></div>
  <div id="view"></div>
</main>

<footer>
  <div class="wrap cols" id="footCols"></div>
  <div class="legal"><div class="wrap" id="legalBar"></div></div>
</footer>

<nav class="bottom" aria-label="Menu"><div class="row">
  <button type="button" data-nav="home" aria-current="true"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M4 11 12 4l8 7v9h-5v-6H9v6H4z"/></svg><span data-t="navHome">Home</span></button>
  <button type="button" data-nav="cats"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="4" width="7" height="7" rx="2"/><rect x="13" y="4" width="7" height="7" rx="2"/><rect x="4" y="13" width="7" height="7" rx="2"/><rect x="13" y="13" width="7" height="7" rx="2"/></svg><span data-t="navCats">Categorie</span></button>
  <button type="button" data-nav="search"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg><span data-t="navSearch">Cerca</span></button>
  <button type="button" data-nav="cart" id="navCart"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 4h2l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.5L21 8H6.2"/><circle cx="10" cy="20.5" r="1.3"/><circle cx="17.5" cy="20.5" r="1.3"/></svg><span data-t="cart">Carrello</span><span class="dot2" id="navDot" hidden>0</span></button>
</div></nav>

<div class="scrim" id="scrim"></div>
<aside class="drawer" id="drawer" aria-labelledby="drawerTitle" aria-hidden="true">
  <div class="drawer-head"><h3 id="drawerTitle">Carrello</h3><button class="x" type="button" data-close aria-label="Chiudi"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
  <div class="drawer-body" id="drawerBody"></div>
  <div class="drawer-foot" id="drawerFoot"></div>
</aside>
<div class="modal" id="modal" aria-hidden="true"><div class="box" id="modalBox" role="dialog" aria-modal="true"></div></div>
<div class="toast" id="toast" role="status" aria-live="polite"></div>


<script>window.KR_DATA=<?php echo wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;window.KR_WOO=<?php echo wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;</script>
<script src="<?php echo esc_url(kr_asset('app.js')); ?>?v=<?php echo filemtime(__FILE__); ?>"></script>
<?php wp_footer(); ?></body></html>
