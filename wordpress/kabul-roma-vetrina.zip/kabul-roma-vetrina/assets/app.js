
const DATA = window.KR_DATA;
const SHOP = DATA.negozio;
const REDUCED = matchMedia("(prefers-reduced-motion: reduce)").matches;
const HOVER = matchMedia("(hover: hover)").matches;
const TOUCH = matchMedia("(pointer: coarse)").matches;

/* ================= i18n ================= */
const T = {
 it:{previewTag:"Anteprima",previewMsg:"Prodotti e prezzi presi dal sito attuale, da confermare con il negozio.",storeIn:"Negozio in",searchPh:"Cerca pistacchi, zereshk, tè…",cart:"Carrello",yourCart:"Il tuo carrello",
  s1e:"Afghanistan · Iran · Roma",s1t:"Il sapore di Kabul, a Roma",s1p:"Frutta secca, tè e specialità afghane e iraniane, dal nostro negozio all'Esquilino, vicino a Piazza Vittorio.",s1c:"Scopri la frutta secca",
  s2e:"Frutta secca",s2t:"Tre pistacchi, tre caratteri",s2p:"Semplice, salato o salato con zafferano.",s2c:"Scegli il tuo",
  s3e:"Dispensa persiana",s3t:"Zereshk per il tuo polo",s3p:"Il crespino acidulo che dà carattere al riso con zafferano.",s3c:"Vedi lo zereshk",
  s4e:"Spedizioni",s4t:"Spediamo in tutta Italia",s4p:"Con DHL, UPS e Poste Italiane.",s4c:"Spedizioni e resi",
  teaE:"Tè",teaT:"Il tè delle nostre case",shopE:"Vieni a trovarci",shopT:"Aperto tutti i giorni",openNow:"Aperto ora · fino alle 22",closedNow:"Chiuso ora · apre alle 8",go:"Scopri",
  f1:"Negozio all'Esquilino",f1s:"Via Lamarmora 15, vicino a Piazza Vittorio",f2:"Aperto tutti i giorni",f2s:"Dalle 8:00 alle 22:00",f3:"Spedizioni in Italia",f3s:"DHL, UPS, Poste Italiane",f4:"Reso entro 14 giorni",f4s:"Senza dover dare spiegazioni",
  dried:"Frutta secca",driedSub:"Pistacchi, uvetta, albicocche e zereshk",tea:"Tè",teaSub:"Per il chai di ogni giorno",seeAll:"Vedi tutti",prev:"Precedenti",next:"Successivi",
  kashkE:"Dalla dispensa",fromIran:"Dall'Iran",
  instoreT:"In negozio trovi molto di più",instoreP:"Online c'è una prima selezione. In negozio, a due passi da Piazza Vittorio, trovi anche carne halal, riso e farine, bevande, dolci e snack.",
  storeT:"Kabul Roma, Esquilino",addr:"Indirizzo",hours:"Orari",everyDay:"Tutti i giorni, 8:00–22:00",phone:"Telefono",phone2:"Servizio clienti",email:"Email",regOffice:"Sede legale",shareCap:"Capitale sociale",vat:"P.IVA",rea:"REA",maps:"Apri in Google Maps",copy:"Copia",copied:"Copiato",
  add:"Aggiungi",addToCart:"Aggiungi al carrello",oos:"Esaurito",perKg:"/kg",products:"prodotti",inStore:"Disponibile in negozio",online:"online",
  all:"Tutti",allProducts:"Tutti i prodotti",results:"Risultati per",noRes:"Nessun prodotto trovato. Prova con “pistacchio”, “uvetta” o “tè”.",showAll:"Vedi tutti i risultati",
  emptyCatT:"Questa categoria è in negozio",emptyCatP:"Questi prodotti non sono ancora online. Li trovi in Via Lamarmora 15, tutti i giorni dalle 8 alle 22, oppure chiama il negozio per la disponibilità.",goStore:"Come arrivare",
  allCats:"Tutte le categorie",navHome:"Home",navCats:"Categorie",navSearch:"Cerca",
  emptyCart:"Il carrello è vuoto",emptyCartP:"Aggiungi qualcosa dagli scaffali: frutta secca, tè, kashk.",startShop:"Inizia la spesa",
  subtotal:"Prodotti",shipping:"Spedizione",shipTbd:"La conferma il negozio",total:"Totale prodotti",checkout:"Procedi all'ordine",
  orderNote:"Prepari l'ordine qui e lo invii al negozio su WhatsApp. Il negozio ti conferma disponibilità, spedizione e pagamento.",
  back:"Indietro",name:"Nome e cognome",phoneF:"Telefono",how:"Consegna",ship:"Spedizione",shipS:"In tutta Italia",pickup:"Ritiro in negozio",pickupS:"Via Lamarmora 15",address:"Indirizzo di spedizione",addrPh:"Via, numero, CAP, città",notes:"Note (facoltative)",
  review:"Rivedi l'ordine",required:"Compila i campi evidenziati",orderReady:"Ordine pronto",orderReadyP:"Invia il messaggio su WhatsApp oppure copialo. L'ordine è confermato solo quando risponde il negozio.",sendWa:"Invia su WhatsApp",copyText:"Copia il testo",
  added:"Aggiunto",importer:"Importatore",impVal:"Kabul Groothandel, L'Aia (Paesi Bassi)",size:"Formato",origin:"Origine",code:"Codice",avail:"Disponibilità",yes:"Disponibile",
  infoT:"Spedizioni e resi",infoShipT:"Spedizioni",infoShip:["Spediamo in tutta Italia con DHL, UPS e Poste Italiane.","Costi e tempi te li conferma il negozio insieme all'ordine.","Puoi anche ritirare in negozio, in Via Lamarmora 15."],infoRetT:"Resi e rimborsi",infoRet:["Hai 14 giorni dal ricevimento della merce per annullare l'ordine senza dare spiegazioni.","Il rimborso arriva entro 30 giorni da quando il negozio riceve la merce restituita.","Le spese di spedizione del reso sono a carico del cliente."],
  fAbout:"Alimentari afghani e iraniani a Roma. Frutta secca, tè e specialità della dispensa, in negozio e online.",fShop:"Negozio",fContact:"Contatti",fHelp:"Aiuto",fShipRet:"Spedizioni e resi",fAllCats:"Tutte le categorie",legalNote:"Partita IVA da inserire",
  close:"Chiudi",clear:"Cancella",search:"Cerca"},
 en:{previewTag:"Preview",previewMsg:"Products and prices taken from the current site, to be confirmed with the shop.",storeIn:"Shop at",searchPh:"Search pistachios, zereshk, tea…",cart:"Cart",yourCart:"Your cart",
  s1e:"Afghanistan · Iran · Rome",s1t:"The taste of Kabul, in Rome",s1p:"Dried fruit, tea and Afghan and Iranian specialities from our shop in Esquilino, by Piazza Vittorio.",s1c:"Shop dried fruit",
  s2e:"Dried fruit & nuts",s2t:"Three pistachios, three characters",s2p:"Plain, salted, or salted with saffron.",s2c:"Pick yours",
  s3e:"Persian pantry",s3t:"Zereshk for your polo",s3p:"The tart barberry that brings saffron rice to life.",s3c:"See zereshk",
  s4e:"Shipping",s4t:"We ship across Italy",s4p:"With DHL, UPS and Poste Italiane.",s4c:"Shipping & returns",
  teaE:"Tea",teaT:"The tea we drink at home",shopE:"Visit us",shopT:"Open every day",openNow:"Open now · until 22:00",closedNow:"Closed now · opens at 8:00",go:"Explore",
  f1:"Shop in Esquilino",f1s:"Via Lamarmora 15, by Piazza Vittorio",f2:"Open every day",f2s:"8:00 to 22:00",f3:"Shipping in Italy",f3s:"DHL, UPS, Poste Italiane",f4:"14-day returns",f4s:"No reason needed",
  dried:"Dried fruit & nuts",driedSub:"Pistachios, raisins, apricots and zereshk",tea:"Tea",teaSub:"For everyday chai",seeAll:"See all",prev:"Previous",next:"Next",
  kashkE:"From the pantry",fromIran:"From Iran",
  instoreT:"There's much more in the shop",instoreP:"Online you'll find a first selection. In the shop near Piazza Vittorio we also have halal meat, rice and flour, drinks, sweets and snacks.",
  storeT:"Kabul Roma, Esquilino",addr:"Address",hours:"Opening hours",everyDay:"Every day, 8:00–22:00",phone:"Phone",phone2:"Customer service",email:"Email",regOffice:"Registered office",shareCap:"Share capital",vat:"VAT no.",rea:"REA",maps:"Open in Google Maps",copy:"Copy",copied:"Copied",
  add:"Add",addToCart:"Add to cart",oos:"Sold out",perKg:"/kg",products:"products",inStore:"Available in the shop",online:"online",
  all:"All",allProducts:"All products",results:"Results for",noRes:"No products found. Try “pistachio”, “raisins” or “tea”.",showAll:"See all results",
  emptyCatT:"This category is in the shop",emptyCatP:"These products aren't online yet. Find them at Via Lamarmora 15, every day from 8:00 to 22:00, or call the shop to check availability.",goStore:"Directions",
  allCats:"All categories",navHome:"Home",navCats:"Categories",navSearch:"Search",
  emptyCart:"Your cart is empty",emptyCartP:"Add something from the shelves: dried fruit, tea, kashk.",startShop:"Start shopping",
  subtotal:"Products",shipping:"Shipping",shipTbd:"Confirmed by the shop",total:"Products total",checkout:"Checkout",
  orderNote:"Prepare your order here and send it to the shop on WhatsApp. The shop confirms availability, shipping and payment.",
  back:"Back",name:"Full name",phoneF:"Phone",how:"Delivery",ship:"Shipping",shipS:"Anywhere in Italy",pickup:"Pick up in shop",pickupS:"Via Lamarmora 15",address:"Shipping address",addrPh:"Street, number, postcode, city",notes:"Notes (optional)",
  review:"Review order",required:"Fill in the highlighted fields",orderReady:"Order ready",orderReadyP:"Send the message on WhatsApp or copy it. Your order is confirmed only when the shop replies.",sendWa:"Send on WhatsApp",copyText:"Copy text",
  added:"Added",importer:"Importer",impVal:"Kabul Groothandel, The Hague (Netherlands)",size:"Size",origin:"Origin",code:"Code",avail:"Availability",yes:"In stock",
  infoT:"Shipping & returns",infoShipT:"Shipping",infoShip:["We ship across Italy with DHL, UPS and Poste Italiane.","The shop confirms costs and delivery times with your order.","You can also pick up in the shop at Via Lamarmora 15."],infoRetT:"Returns & refunds",infoRet:["You have 14 days from receiving the goods to cancel your order without giving a reason.","Refunds are issued within 30 days of the shop receiving the returned goods.","Return shipping costs are paid by the customer."],
  fAbout:"Afghan and Iranian groceries in Rome. Dried fruit, tea and pantry specialities, in the shop and online.",fShop:"Shop",fContact:"Contact",fHelp:"Help",fShipRet:"Shipping & returns",fAllCats:"All categories",legalNote:"VAT number to be added",
  close:"Close",clear:"Clear",search:"Search"},
 fa:{previewTag:"پیش‌نمایش",previewMsg:"محصولات و قیمت‌ها از سایت فعلی گرفته شده و باید با فروشگاه تأیید شود.",storeIn:"فروشگاه در",searchPh:"جستجوی پسته، زرشک، چای…",cart:"سبد خرید",yourCart:"سبد خرید شما",
  s1e:"افغانستان · ایران · رم",s1t:"طعم کابل، در رم",s1p:"خشکبار، چای و خوراکی‌های افغانی و ایرانی از فروشگاه ما در اسکوئیلینو، نزدیک میدان ویتوریو.",s1c:"خرید خشکبار",
  s2e:"خشکبار",s2t:"سه پسته، سه طعم",s2p:"ساده، شور، یا شور زعفرانی.",s2c:"انتخاب کنید",
  s3e:"آشپزخانهٔ ایرانی",s3t:"زرشک برای پلوی شما",s3p:"زرشک ترش که به پلوی زعفرانی جان می‌دهد.",s3c:"دیدن زرشک",
  s4e:"ارسال",s4t:"ارسال به سراسر ایتالیا",s4p:"با DHL، UPS و پست ایتالیا.",s4c:"ارسال و مرجوعی",
  teaE:"چای",teaT:"چای خانه‌های ما",shopE:"به ما سر بزنید",shopT:"هر روز باز است",openNow:"اکنون باز است · تا ساعت ۲۲",closedNow:"اکنون بسته است · از ساعت ۸",go:"ببینید",
  f1:"فروشگاه در اسکوئیلینو",f1s:"Via Lamarmora 15، نزدیک میدان ویتوریو",f2:"هر روز باز",f2s:"از ساعت ۸ تا ۲۲",f3:"ارسال در ایتالیا",f3s:"DHL، UPS، پست ایتالیا",f4:"مرجوعی تا ۱۴ روز",f4s:"بدون نیاز به توضیح",
  dried:"خشکبار",driedSub:"پسته، کشمش، زردآلو و زرشک",tea:"چای",teaSub:"برای چای هر روز",seeAll:"همه",prev:"قبلی",next:"بعدی",
  kashkE:"از آشپزخانه",fromIran:"از ایران",
  instoreT:"در فروشگاه خیلی بیشتر پیدا می‌کنید",instoreP:"در سایت گزیده‌ای از محصولات هست. در فروشگاه نزدیک میدان ویتوریو گوشت حلال، برنج و آرد، نوشیدنی، شیرینی و تنقلات هم داریم.",
  storeT:"کابل روما، اسکوئیلینو",addr:"آدرس",hours:"ساعات کار",everyDay:"هر روز، ۸:۰۰ تا ۲۲:۰۰",phone:"تلفن",phone2:"خدمات مشتریان",email:"ایمیل",regOffice:"دفتر ثبت‌شده",shareCap:"سرمایه",vat:"شمارهٔ مالیاتی",rea:"REA",maps:"باز کردن در گوگل مپ",copy:"کپی",copied:"کپی شد",
  add:"افزودن",addToCart:"افزودن به سبد",oos:"ناموجود",perKg:"/کیلو",products:"محصول",inStore:"موجود در فروشگاه",online:"آنلاین",
  all:"همه",allProducts:"همهٔ محصولات",results:"نتایج برای",noRes:"محصولی پیدا نشد. «پسته»، «کشمش» یا «چای» را امتحان کنید.",showAll:"دیدن همهٔ نتایج",
  emptyCatT:"این دسته در فروشگاه موجود است",emptyCatP:"این محصولات هنوز آنلاین نیستند. آن‌ها را در Via Lamarmora 15، هر روز از ساعت ۸ تا ۲۲ پیدا می‌کنید، یا برای موجودی با فروشگاه تماس بگیرید.",goStore:"مسیریابی",
  allCats:"همهٔ دسته‌ها",navHome:"خانه",navCats:"دسته‌ها",navSearch:"جستجو",
  emptyCart:"سبد خرید خالی است",emptyCartP:"از قفسه‌ها چیزی اضافه کنید: خشکبار، چای، کشک.",startShop:"شروع خرید",
  subtotal:"محصولات",shipping:"ارسال",shipTbd:"فروشگاه تأیید می‌کند",total:"جمع محصولات",checkout:"ادامهٔ سفارش",
  orderNote:"سفارش را اینجا آماده کنید و در واتس‌اپ برای فروشگاه بفرستید. فروشگاه موجودی، ارسال و پرداخت را تأیید می‌کند.",
  back:"بازگشت",name:"نام و نام خانوادگی",phoneF:"تلفن",how:"تحویل",ship:"ارسال",shipS:"به سراسر ایتالیا",pickup:"تحویل از فروشگاه",pickupS:"Via Lamarmora 15",address:"آدرس ارسال",addrPh:"خیابان، پلاک، کد پستی، شهر",notes:"یادداشت (اختیاری)",
  review:"مرور سفارش",required:"فیلدهای مشخص‌شده را پر کنید",orderReady:"سفارش آماده است",orderReadyP:"پیام را در واتس‌اپ بفرستید یا کپی کنید. سفارش وقتی تأیید می‌شود که فروشگاه پاسخ دهد.",sendWa:"ارسال در واتس‌اپ",copyText:"کپی متن",
  added:"اضافه شد",importer:"واردکننده",impVal:"Kabul Groothandel، لاهه (هلند)",size:"اندازه",origin:"مبدأ",code:"کد",avail:"موجودی",yes:"موجود",
  infoT:"ارسال و مرجوعی",infoShipT:"ارسال",infoShip:["با DHL، UPS و پست ایتالیا به سراسر ایتالیا ارسال می‌کنیم.","هزینه و زمان ارسال را فروشگاه همراه سفارش تأیید می‌کند.","می‌توانید سفارش را از فروشگاه در Via Lamarmora 15 تحویل بگیرید."],infoRetT:"مرجوعی و بازپرداخت",infoRet:["تا ۱۴ روز پس از دریافت کالا می‌توانید بدون ذکر دلیل سفارش را لغو کنید.","بازپرداخت ظرف ۳۰ روز پس از دریافت کالای مرجوعی انجام می‌شود.","هزینهٔ ارسال مرجوعی با مشتری است."],
  fAbout:"مواد غذایی افغانی و ایرانی در رم. خشکبار، چای و خوراکی‌ها، در فروشگاه و آنلاین.",fShop:"فروشگاه",fContact:"تماس",fHelp:"راهنما",fShipRet:"ارسال و مرجوعی",fAllCats:"همهٔ دسته‌ها",legalNote:"شمارهٔ مالیاتی بعداً اضافه می‌شود",
  close:"بستن",clear:"پاک کردن",search:"جستجو"}
};
const LOC = {it:"it-IT",en:"en-IE",fa:"fa-IR"};
let lang = "it";
try{ const s = localStorage.getItem("kr_lang"); if(T[s]) lang = s; }catch(e){}
const t = k => (T[lang][k] ?? T.it[k] ?? k);
const L = o => (o && (o[lang] ?? o.it)) || "";
const money = n => new Intl.NumberFormat(LOC[lang],{style:"currency",currency:"EUR"}).format(n);
const moneyIt = n => new Intl.NumberFormat("it-IT",{style:"currency",currency:"EUR"}).format(n);
const digits = s => lang==="fa" ? String(s).replace(/\d/g,d=>"۰۱۲۳۴۵۶۷۸۹"[d]) : String(s);
const esc = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const sizeLbl = g => g==null ? "" : g>=1000 ? digits(g/1000)+(lang==="fa"?" کیلو":" kg") : digits(g)+(lang==="fa"?" گرم":" g");
const sizeIt = g => g==null ? "" : g>=1000 ? (g/1000)+" kg" : g+" g";

/* ================= data ================= */
const CATS = DATA.categorie.map(([id,it,en,fa])=>({id,it,en,fa}));
const P = DATA.prodotti.map((p,i)=>({...p,id:"KR"+String(i+1).padStart(3,"0"),seed:i+1}));
const byId = Object.fromEntries(P.map(p=>[p.id,p]));
const inCat = id => P.filter(p=>p.cat===id);
const catById = id => CATS.find(c=>c.id===id);
const sel = {};
const vIdx = p => sel[p.id] ?? 0;
const keyOf = p => p.id+"|"+vIdx(p);

/* ================= packaging illustrations ================= */
let UID = 0;
function shade(hex,amt){const n=parseInt(hex.slice(1),16);const f=v=>Math.max(0,Math.min(255,v+amt));return "#"+((1<<24)+(f(n>>16)<<16)+(f(n>>8&255)<<8)+f(n&255)).toString(16).slice(1)}
function rng(seed){let a=seed*9301+49297;return()=>{a|=0;a=a+0x6D2B79F5|0;let q=Math.imul(a^a>>>15,1|a);q=q+Math.imul(q^q>>>7,61|q)^q;return((q^q>>>14)>>>0)/4294967296}}
const FILLS = {
  apricot:{bg:"#b35a12",cols:["#f39a2e","#e8862a","#f7b04a"],r:[7,9],ry:.85},
  chickpea:{bg:"#9b7a3c",cols:["#e9cf98","#dcbc7c","#f1dcae"],r:[5,6.5],ry:.95},
  pistachio:{bg:"#8a7a52",cols:["#e9dcbc","#dccaa0"],r:[6,7.5],ry:.62,kernel:"#8fbf3f"},
  raisinBlack:{bg:"#140c18",cols:["#3b2440","#2a1830","#4a2d50"],r:[3.6,4.6],ry:.7},
  raisinRed:{bg:"#3d0f15",cols:["#8c2a2e","#a13438","#73222a"],r:[3.6,4.6],ry:.7},
  raisinGreen:{bg:"#5c5a1c",cols:["#c2b94e","#adb042","#d4c862"],r:[3.2,4.2],ry:.55},
  berry:{bg:"#5e0612",cols:["#d4213b","#b8152d","#e8394f"],r:[2.6,3.4],ry:.95}
};
function contents(kind,x,y,w,h,seed,u){
  const f=FILLS[kind]; if(!f) return "";
  const R=rng(seed); let s=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${f.bg}"/>`;
  const step=f.r[1]*1.55;
  for(let yy=y+step*.4; yy<y+h+step; yy+=step*.82){
    for(let xx=x-step*.3+(R()*step*.5); xx<x+w+step; xx+=step*(.9+R()*.25)){
      const r=f.r[0]+R()*(f.r[1]-f.r[0]), a=Math.round(R()*180), c=f.cols[(R()*f.cols.length)|0], X=xx.toFixed(1), Y=yy.toFixed(1);
      s+=`<ellipse cx="${X}" cy="${Y}" rx="${r.toFixed(1)}" ry="${(r*f.ry).toFixed(1)}" fill="${c}" transform="rotate(${a} ${X} ${Y})"/>`;
      if(f.kernel && R()>.35) s+=`<ellipse cx="${X}" cy="${Y}" rx="${(r*.45).toFixed(1)}" ry="${(r*.22).toFixed(1)}" fill="${f.kernel}" transform="rotate(${a} ${X} ${Y})"/>`;
    }
  }
  return `<g clip-path="url(#w${u})">${s}<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#gl${u})"/></g>`;
}
function star(cx,cy,r,col,sw=1.4){let d="";for(let k=0;k<16;k++){const a=Math.PI*2*k/16-Math.PI/2,rr=k%2?r*.45:r;d+=(k?"L":"M")+(cx+Math.cos(a)*rr).toFixed(1)+" "+(cy+Math.sin(a)*rr).toFixed(1)}return `<path d="${d}Z" fill="none" stroke="${col}" stroke-width="${sw}"/>`}
function pack(p,vi){
  const u="k"+(++UID), c=p.pc, dark=shade(c,-38), light=shade(c,30);
  const et=(p.et&&(p.et[lang]??p.et.it))||[L(p),""];
  const fa=lang==="fa";
  const ff=fa?"Vazirmatn,Tahoma,sans-serif":"Bricolage Grotesque,Figtree,sans-serif";
  const l1=esc(et[0]), l2=esc(et[1]||"");
  const fs1=Math.min(15,+(64/(et[0].length*.6)).toFixed(1));
  const v=p.v[vi ?? vIdx(p)]||p.v[0], sz=v[0]?esc(sizeLbl(v[0])):"";
  const defs=`<defs>
    <linearGradient id="b${u}" x1="0" x2="1"><stop offset="0" stop-color="${light}"/><stop offset=".45" stop-color="${c}"/><stop offset="1" stop-color="${dark}"/></linearGradient>
    <linearGradient id="h${u}" x1="0" x2="1"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".22"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>
    <linearGradient id="gl${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".3"/><stop offset=".35" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".2"/></linearGradient>
    <clipPath id="w${u}"><rect x="56" y="102" width="68" height="46" rx="23"/></clipPath>
  </defs>`;
  const label=(x,y,w,h)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="8" fill="#fffaf0"/>
    <text x="${x+w/2}" y="${y+(l2?h*.47:h*.62)}" text-anchor="middle" font-family="${ff}" font-weight="800" font-size="${fs1}" fill="${dark}">${l1}</text>
    ${l2?`<text x="${x+w/2}" y="${y+h*.82}" text-anchor="middle" font-family="${ff}" font-weight="600" font-size="9.5" fill="${shade(dark,20)}">${l2}</text>`:""}`;
  let body="";
  if(p.shape==="pouch"){
    body=`<path d="M44 26h92l7 136q.4 8-7.6 8H44.6q-8 0-7.6-8z" fill="url(#b${u})"/>
      <path d="M44 26h92v14H44z" fill="${dark}"/>
      <path d="M44 26l4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6 4.6 6 4.6-6z" fill="${dark}"/>
      <circle cx="90" cy="32" r="3.6" fill="#000" opacity=".28"/>
      <path d="M46 46h88" stroke="#fff" stroke-opacity=".35" stroke-width="1.6" stroke-dasharray="2 3"/>
      ${label(54,54,72,38)}
      <rect x="54" y="100" width="72" height="50" rx="25" fill="#000" opacity=".18"/>
      ${contents(p.fill,56,102,68,46,p.seed*7,u)}
      <rect x="56" y="102" width="68" height="46" rx="23" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="1.5"/>
      ${sz?`<text x="90" y="163" text-anchor="middle" font-family="Figtree,Vazirmatn,sans-serif" font-weight="800" font-size="9" fill="#fff" opacity=".92">${sz}</text>`:""}
      <path d="M50 30q-4 60 0 134" stroke="url(#h${u})" stroke-width="10" fill="none" opacity=".9"/>`;
  } else if(p.shape==="box"){
    body=`<path d="M40 44 62 28h86l-22 16z" fill="${light}"/>
      <path d="M126 44 148 28v122l-22 16z" fill="${dark}"/>
      <rect x="40" y="44" width="86" height="122" fill="url(#b${u})"/>
      <rect x="40" y="44" width="86" height="12" fill="${dark}" opacity=".5"/>
      ${star(83,138,14,"#fff")}${star(83,138,7,"#f2a20c")}
      ${label(48,64,70,40)}
      <text x="83" y="120" text-anchor="middle" font-family="${fa?ff:"Figtree,sans-serif"}" font-weight="800" font-size="9" letter-spacing="${fa?0:2}" fill="#fff" opacity=".85">${fa?"چای":"TEA"}</text>
      ${sz?`<text x="83" y="162" text-anchor="middle" font-family="Figtree,Vazirmatn,sans-serif" font-weight="800" font-size="9" fill="#fff" opacity=".9">${sz}</text>`:""}
      <path d="M46 48v114" stroke="url(#h${u})" stroke-width="9" opacity=".8"/>`;
  } else {
    body=`<rect x="50" y="30" width="80" height="22" rx="7" fill="${c}"/><rect x="50" y="44" width="80" height="8" fill="${dark}"/>
      <path d="M46 56h88q8 0 8 10v88q0 12-12 12H50q-12 0-12-12V66q0-10 8-10z" fill="#f4efe2"/>
      <path d="M46 56h88q8 0 8 10v88q0 12-12 12H50q-12 0-12-12V66q0-10 8-10z" fill="url(#gl${u})"/>
      <rect x="38" y="82" width="104" height="58" fill="${c}"/>
      ${star(50,111,7,"#f2a20c",1.2)}${star(130,111,7,"#f2a20c",1.2)}
      <text x="90" y="${fa?119:117}" text-anchor="middle" font-family="${ff}" font-weight="800" font-size="18" fill="#fff">${l1}</text>
      ${sz?`<text x="90" y="133" text-anchor="middle" font-family="Figtree,Vazirmatn,sans-serif" font-weight="700" font-size="9" fill="#fff" opacity=".85">${sz}</text>`:""}
      <path d="M46 62v96" stroke="#fff" stroke-opacity=".5" stroke-width="6" stroke-linecap="round"/>`;
  }
  return `<svg viewBox="0 0 180 180" role="img" aria-label="${esc(L(p))}">${defs}<ellipse cx="90" cy="172" rx="52" ry="6" fill="#000" opacity=".12"/>${body}</svg>`;
}

const media = p => p.img ? `<img src="${p.img}" alt="${esc(L(p))}" width="560" height="560" decoding="async" draggable="false">` : pack(p);
const CAT_ICON = {
 fruttasecca:`<ellipse cx="24" cy="36" rx="10" ry="13" fill="#e8d6ae" transform="rotate(-22 24 36)"/><ellipse cx="24" cy="36" rx="4" ry="9" fill="#8fbf3f" transform="rotate(-22 24 36)"/><ellipse cx="41" cy="34" rx="10" ry="12" fill="#f39a2e" transform="rotate(18 41 34)"/><path d="M41 23q3 4 0 8" stroke="#b35a12" stroke-width="2" fill="none"/>`,
 te:`<path d="M14 28h30v8a15 15 0 0 1-30 0z" fill="#1f8a4c"/><path d="M44 31h4a6 6 0 0 1 0 12h-6" stroke="#1f8a4c" stroke-width="3.2" fill="none"/><path d="M22 14c0 4 4 4 4 9M31 12c0 4 4 4 4 9" stroke="#9aa3be" stroke-width="2.4" fill="none" stroke-linecap="round"/><rect x="10" y="49" width="40" height="4" rx="2" fill="#1d3a8a"/>`,
 scatola:`<rect x="16" y="14" width="32" height="9" rx="3" fill="#1d3a8a"/><rect x="13" y="22" width="38" height="30" rx="8" fill="#f4efe2" stroke="#d8cfb8" stroke-width="1.5"/><rect x="13" y="30" width="38" height="13" fill="#1d3a8a"/><circle cx="32" cy="36.5" r="3.5" fill="#f2a20c"/>`,
 riso:`<path d="M12 33c0-10 9-17 20-17s20 7 20 17z" fill="#f4efe2"/><g fill="#d8cfb8"><ellipse cx="24" cy="25" rx="2.4" ry="1.1"/><ellipse cx="32" cy="21" rx="2.4" ry="1.1"/><ellipse cx="39" cy="26" rx="2.4" ry="1.1"/><ellipse cx="29" cy="28" rx="2.4" ry="1.1"/></g><path d="M8 33h48c0 10-11 16-24 16S8 43 8 33z" fill="#c8102e"/><path d="M14 38h36" stroke="#f2a20c" stroke-width="2" stroke-dasharray="3 3"/>`,
 carne:`<path d="M18 20c10-8 28-6 32 6 4 12-4 24-16 24-8 0-10-6-16-8-8-3-8-15 0-22z" fill="#d8455a"/><path d="M22 26c6-4 16-4 20 2" stroke="#f6c3cb" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="34" cy="36" r="5" fill="#f6c3cb"/>`,
 pasta:`<g stroke="#f2a20c" stroke-width="3" fill="none" stroke-linecap="round"><path d="M14 46c6-14 12-24 20-30"/><path d="M20 48c6-14 12-24 20-30"/><path d="M26 49c6-14 12-24 20-30"/></g><g fill="#8a2b2b"><ellipse cx="44" cy="44" rx="5" ry="3.5"/><ellipse cx="50" cy="38" rx="5" ry="3.5"/></g>`,
 bevande:`<path d="M27 10h10v8l6 8v26a3 3 0 0 1-3 3H24a3 3 0 0 1-3-3V26l6-8z" fill="#2a8fbf"/><rect x="21" y="32" width="22" height="10" fill="#fff" opacity=".85"/><rect x="27" y="7" width="10" height="5" rx="1.5" fill="#1d3a8a"/>`,
 energetiche:`<rect x="20" y="10" width="24" height="44" rx="6" fill="#1d3a8a"/><rect x="20" y="10" width="24" height="5" rx="2" fill="#9aa3be"/><path d="M34 20 26 34h6l-3 12 9-16h-6z" fill="#f2a20c"/>`,
 cioccolato:`<g transform="rotate(-10 29 33)"><rect x="14" y="16" width="30" height="34" rx="4" fill="#6b3b22"/><g stroke="#4a2614" stroke-width="2"><path d="M14 27h30M14 38h30M29 16v34"/></g></g><g fill="#5a3019"><circle cx="45" cy="44" r="5"/><circle cx="51" cy="35" r="4.4"/></g>`,
 snack:`<path d="M18 14h28l4 38H14z" fill="#f2a20c"/><path d="M18 14l2-4h24l2 4z" fill="#c47f0a"/><circle cx="32" cy="32" r="8" fill="#fff" opacity=".9"/><circle cx="32" cy="32" r="4" fill="#c8102e"/>`
};
Object.assign(CAT_ICON, {"fruttasecca": "<ellipse cx=\"24\" cy=\"36\" rx=\"10\" ry=\"13\" fill=\"#e8d6ae\" transform=\"rotate(-22 24 36)\"/><ellipse cx=\"24\" cy=\"36\" rx=\"4\" ry=\"9\" fill=\"#8fbf3f\" transform=\"rotate(-22 24 36)\"/><ellipse cx=\"41\" cy=\"34\" rx=\"10\" ry=\"12\" fill=\"#f39a2e\" transform=\"rotate(18 41 34)\"/><path d=\"M41 23q3 4 0 8\" stroke=\"#b35a12\" stroke-width=\"2\" fill=\"none\"/>", "te": "<path d=\"M14 28h30v8a15 15 0 0 1-30 0z\" fill=\"#1f8a4c\"/><path d=\"M44 31h4a6 6 0 0 1 0 12h-6\" stroke=\"#1f8a4c\" stroke-width=\"3.2\" fill=\"none\"/><path d=\"M22 14c0 4 4 4 4 9M31 12c0 4 4 4 4 9\" stroke=\"#9aa3be\" stroke-width=\"2.4\" fill=\"none\" stroke-linecap=\"round\"/><rect x=\"10\" y=\"49\" width=\"40\" height=\"4\" rx=\"2\" fill=\"#1d3a8a\"/>", "scatola": "<rect x=\"16\" y=\"14\" width=\"32\" height=\"9\" rx=\"3\" fill=\"#1d3a8a\"/><rect x=\"13\" y=\"22\" width=\"38\" height=\"30\" rx=\"8\" fill=\"#f4efe2\" stroke=\"#d8cfb8\" stroke-width=\"1.5\"/><rect x=\"13\" y=\"30\" width=\"38\" height=\"13\" fill=\"#1d3a8a\"/><circle cx=\"32\" cy=\"36.5\" r=\"3.5\" fill=\"#f2a20c\"/>", "riso": "<path d=\"M12 33c0-10 9-17 20-17s20 7 20 17z\" fill=\"#f4efe2\"/><g fill=\"#d8cfb8\"><ellipse cx=\"24\" cy=\"25\" rx=\"2.4\" ry=\"1.1\"/><ellipse cx=\"32\" cy=\"21\" rx=\"2.4\" ry=\"1.1\"/><ellipse cx=\"39\" cy=\"26\" rx=\"2.4\" ry=\"1.1\"/><ellipse cx=\"29\" cy=\"28\" rx=\"2.4\" ry=\"1.1\"/></g><path d=\"M8 33h48c0 10-11 16-24 16S8 43 8 33z\" fill=\"#c8102e\"/><path d=\"M14 38h36\" stroke=\"#f2a20c\" stroke-width=\"2\" stroke-dasharray=\"3 3\"/>", "legumi": "<path d=\"M10 34h44c0 11-10 18-22 18S10 45 10 34z\" fill=\"#9b7a3c\"/><g fill=\"#e9cf98\"><ellipse cx=\"20\" cy=\"30\" rx=\"5\" ry=\"4\"/><ellipse cx=\"30\" cy=\"27\" rx=\"5\" ry=\"4\"/><ellipse cx=\"41\" cy=\"29\" rx=\"5\" ry=\"4\"/><ellipse cx=\"25\" cy=\"33\" rx=\"5\" ry=\"3.5\"/><ellipse cx=\"36\" cy=\"33\" rx=\"5\" ry=\"3.5\"/><ellipse cx=\"46\" cy=\"32\" rx=\"4.5\" ry=\"3.5\"/></g><g fill=\"#c8102e\"><ellipse cx=\"33\" cy=\"22\" rx=\"3.6\" ry=\"2.6\"/><ellipse cx=\"44\" cy=\"24\" rx=\"3.2\" ry=\"2.4\"/></g><g fill=\"#1f8a4c\"><ellipse cx=\"22\" cy=\"24\" rx=\"2.6\" ry=\"2.2\"/></g><path d=\"M16 41h32\" stroke=\"#f2a20c\" stroke-width=\"2\" stroke-dasharray=\"3 3\"/>", "pasta": "<g stroke=\"#f2a20c\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"><path d=\"M14 46c6-14 12-24 20-30\"/><path d=\"M20 48c6-14 12-24 20-30\"/><path d=\"M26 49c6-14 12-24 20-30\"/></g><g fill=\"#8a2b2b\"><ellipse cx=\"44\" cy=\"44\" rx=\"5\" ry=\"3.5\"/><ellipse cx=\"50\" cy=\"38\" rx=\"5\" ry=\"3.5\"/></g>", "spezie": "<ellipse cx=\"32\" cy=\"48\" rx=\"27\" ry=\"6\" fill=\"#cfd6e6\"/><path d=\"M6 46c3-11 9-15 13-15s10 4 12 15z\" fill=\"#c8102e\"/><path d=\"M33 46c2-13 8-18 13-18s11 5 13 18z\" fill=\"#f2a20c\"/><path d=\"M19 48c3-10 8-13 13-13s9 3 11 13z\" fill=\"#e8862a\"/><g stroke=\"#c8102e\" stroke-width=\"1.8\" stroke-linecap=\"round\"><path d=\"M42 12l-2 7M47 11v7M52 13l-3 6\"/></g><g fill=\"#c8102e\"><circle cx=\"40\" cy=\"20\" r=\"1.4\"/><circle cx=\"47\" cy=\"19\" r=\"1.4\"/><circle cx=\"49\" cy=\"20\" r=\"1.4\"/></g>", "condimenti": "<rect x=\"23\" y=\"5\" width=\"14\" height=\"6\" rx=\"2\" fill=\"#1d3a8a\"/><path d=\"M25 10h10v7l5 7v28a4 4 0 0 1-4 4H24a4 4 0 0 1-4-4V24l5-7z\" fill=\"#c8102e\"/><rect x=\"20\" y=\"31\" width=\"20\" height=\"13\" fill=\"#fffaf0\"/><path d=\"M25 38c2-3 8-3 10 0\" stroke=\"#1f8a4c\" stroke-width=\"2.4\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M50 28c0 4-4 7-4 11a4 4 0 0 0 8 0c0-4-4-7-4-11z\" fill=\"#f2a20c\"/><ellipse cx=\"50\" cy=\"54\" rx=\"8\" ry=\"2.4\" fill=\"#f2a20c\" opacity=\".55\"/>", "olio": "<rect x=\"27\" y=\"4\" width=\"10\" height=\"6\" rx=\"2\" fill=\"#1d3a8a\"/><path d=\"M28 9h8v8c6 4 10 9 10 16v19a5 5 0 0 1-5 5H23a5 5 0 0 1-5-5V33c0-7 4-12 10-16z\" fill=\"#d8bf3c\"/><path d=\"M18 37h28v11H18z\" fill=\"#1f8a4c\" opacity=\".9\"/><circle cx=\"32\" cy=\"42.5\" r=\"3\" fill=\"#f2a20c\"/><path d=\"M24 22c-3 3-4 7-4 11\" stroke=\"#fff\" stroke-opacity=\".55\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M53 20c0 3-3 5-3 8a3 3 0 0 0 6 0c0-3-3-5-3-8z\" fill=\"#d8bf3c\"/>", "sciroppi": "<path d=\"M16 18h28l-4 34a4 4 0 0 1-4 3.5H24a4 4 0 0 1-4-3.5z\" fill=\"#ffffff\" stroke=\"#cfd6e6\" stroke-width=\"1.5\"/><path d=\"M18 28h24l-2.8 23.5a3 3 0 0 1-3 2.5H23.8a3 3 0 0 1-3-2.5z\" fill=\"#d4213b\"/><path d=\"M38 8l-5 32\" stroke=\"#1d3a8a\" stroke-width=\"3\" stroke-linecap=\"round\"/><circle cx=\"46\" cy=\"19\" r=\"7\" fill=\"#f2a20c\"/><circle cx=\"46\" cy=\"19\" r=\"4.6\" fill=\"#ffd27a\"/><path d=\"M46 14.4v9.2M41.4 19h9.2\" stroke=\"#f2a20c\" stroke-width=\"1\"/><g fill=\"#fff\" opacity=\".75\"><circle cx=\"26\" cy=\"38\" r=\"2\"/><circle cx=\"31\" cy=\"45\" r=\"1.6\"/><circle cx=\"35\" cy=\"34\" r=\"1.3\"/></g>", "bevande": "<path d=\"M27 10h10v8l6 8v26a3 3 0 0 1-3 3H24a3 3 0 0 1-3-3V26l6-8z\" fill=\"#2a8fbf\"/><rect x=\"21\" y=\"32\" width=\"22\" height=\"10\" fill=\"#fff\" opacity=\".85\"/><rect x=\"27\" y=\"7\" width=\"10\" height=\"5\" rx=\"1.5\" fill=\"#1d3a8a\"/>", "energetiche": "<rect x=\"20\" y=\"10\" width=\"24\" height=\"44\" rx=\"6\" fill=\"#1d3a8a\"/><rect x=\"20\" y=\"10\" width=\"24\" height=\"5\" rx=\"2\" fill=\"#9aa3be\"/><path d=\"M34 20 26 34h6l-3 12 9-16h-6z\" fill=\"#f2a20c\"/>", "dolci": "<path d=\"M8 38 32 22l24 16-24 16z\" fill=\"#e8b04a\"/><path d=\"M8 38v6l24 16v-6z\" fill=\"#c47f0a\"/><path d=\"M56 38v6L32 60v-6z\" fill=\"#d9951a\"/><path d=\"M20 30l24 16M44 30 20 46\" stroke=\"#b07010\" stroke-width=\"1.4\"/><g fill=\"#8fbf3f\"><circle cx=\"32\" cy=\"38\" r=\"2.6\"/><circle cx=\"20\" cy=\"38\" r=\"1.9\"/><circle cx=\"44\" cy=\"38\" r=\"1.9\"/><circle cx=\"32\" cy=\"29\" r=\"1.9\"/><circle cx=\"32\" cy=\"47\" r=\"1.9\"/></g><path d=\"M28 12c2-4 6-4 8 0-2 3-6 3-8 0z\" fill=\"#c8102e\"/>", "cioccolato": "<g transform=\"rotate(-10 29 33)\"><rect x=\"14\" y=\"16\" width=\"30\" height=\"34\" rx=\"4\" fill=\"#6b3b22\"/><g stroke=\"#4a2614\" stroke-width=\"2\"><path d=\"M14 27h30M14 38h30M29 16v34\"/></g></g><g fill=\"#5a3019\"><circle cx=\"45\" cy=\"44\" r=\"5\"/><circle cx=\"51\" cy=\"35\" r=\"4.4\"/></g>", "snack": "<path d=\"M18 14h28l4 38H14z\" fill=\"#f2a20c\"/><path d=\"M18 14l2-4h24l2 4z\" fill=\"#c47f0a\"/><circle cx=\"32\" cy=\"32\" r=\"8\" fill=\"#fff\" opacity=\".9\"/><circle cx=\"32\" cy=\"32\" r=\"4\" fill=\"#c8102e\"/>", "latticini": "<rect x=\"8\" y=\"16\" width=\"34\" height=\"8\" rx=\"3\" fill=\"#2a8fbf\"/><path d=\"M10 22h30l-3.5 30a4 4 0 0 1-4 3.5h-15a4 4 0 0 1-4-3.5z\" fill=\"#ffffff\" stroke=\"#cfd6e6\" stroke-width=\"1.5\"/><rect x=\"12.5\" y=\"32\" width=\"25\" height=\"9\" fill=\"#2a8fbf\" opacity=\".9\"/><path d=\"M34 56V43l22-8v21z\" fill=\"#f6c84a\"/><path d=\"M34 43l22-8-4-3-22 7z\" fill=\"#ffe08a\"/><circle cx=\"43\" cy=\"48\" r=\"2.2\" fill=\"#e0a92a\"/><circle cx=\"50\" cy=\"44\" r=\"1.6\" fill=\"#e0a92a\"/><circle cx=\"49\" cy=\"51\" r=\"1.3\" fill=\"#e0a92a\"/>", "surgelati": "<rect x=\"12\" y=\"14\" width=\"40\" height=\"38\" rx=\"9\" fill=\"#bfe3f5\"/><g stroke=\"#2a8fbf\" stroke-width=\"3\" stroke-linecap=\"round\"><path d=\"M32 20v26M20.7 26.5l22.6 13M20.7 39.5l22.6-13\"/></g><g stroke=\"#2a8fbf\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" fill=\"none\"><path d=\"M28 21.5l4 3 4-3M28 44.5l4-3 4 3\"/></g><path d=\"M18 56h28\" stroke=\"#9aa3be\" stroke-width=\"2.4\" stroke-linecap=\"round\"/>", "carne": "<path d=\"M18 20c10-8 28-6 32 6 4 12-4 24-16 24-8 0-10-6-16-8-8-3-8-15 0-22z\" fill=\"#d8455a\"/><path d=\"M22 26c6-4 16-4 20 2\" stroke=\"#f6c3cb\" stroke-width=\"3\" fill=\"none\" stroke-linecap=\"round\"/><circle cx=\"34\" cy=\"36\" r=\"5\" fill=\"#f6c3cb\"/>", "pane": "<path d=\"M8 38c0-12 12-20 24-20s24 8 24 20c0 6-6 10-12 10H20c-6 0-12-4-12-10z\" fill=\"#e3a857\"/><path d=\"M8 38c0 6 6 10 12 10h24c6 0 12-4 12-10\" fill=\"#c98a3a\" opacity=\".5\"/><g stroke=\"#b06d22\" stroke-width=\"2.4\" stroke-linecap=\"round\"><path d=\"M18 29l6 6M28 25l6 6M38 25l6 6\"/></g><g fill=\"#3b2b1a\"><circle cx=\"22\" cy=\"41\" r=\"1.1\"/><circle cx=\"32\" cy=\"43\" r=\"1.1\"/><circle cx=\"42\" cy=\"41\" r=\"1.1\"/><circle cx=\"27\" cy=\"37\" r=\"1\"/><circle cx=\"37\" cy=\"37\" r=\"1\"/></g>", "casa": "<path d=\"M24 13h15l4 4-4 4H24z\" fill=\"#1d3a8a\"/><path d=\"M43 17h7\" stroke=\"#9aa3be\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-dasharray=\"1.5 2.5\"/><path d=\"M24 21h12v6l6 6v19a4 4 0 0 1-4 4H22a4 4 0 0 1-4-4V33l6-6z\" fill=\"#2a8fbf\"/><rect x=\"18\" y=\"37\" width=\"24\" height=\"10\" fill=\"#fff\" opacity=\".85\"/><rect x=\"40\" y=\"44\" width=\"18\" height=\"12\" rx=\"3\" fill=\"#f2a20c\"/><rect x=\"40\" y=\"44\" width=\"18\" height=\"4.5\" rx=\"2\" fill=\"#1f8a4c\"/>"});
const catIcon = id => `<svg viewBox="0 0 64 64" aria-hidden="true">${CAT_ICON[id]||""}</svg>`;
const ICON = {
  arrow:`<svg class="arr" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>`,
  left:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>`,
  right:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>`,
  plus:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>`,
  minus:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M5 12h14"/></svg>`,
  pin:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/></svg>`,
  clock:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>`,
  truck:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 6.5h11v9h-11zM13.5 9.5h4l3 3.2v2.8h-7"/><circle cx="6.5" cy="17" r="1.8"/><circle cx="17" cy="17" r="1.8"/></svg>`,
  ret:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9h11a5 5 0 0 1 0 10H9"/><path d="M8 5 4 9l4 4"/></svg>`,
  phone:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a1 1 0 0 1-1 1A16 16 0 0 1 4 5a1 1 0 0 1 1-1z"/></svg>`,
  mail:`<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg>`,
  info:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></svg>`,
  check:`<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>`,
  x:`<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>`,
  wa:`<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2a8.2 8.2 0 0 1-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.3-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5a1 1 0 0 0-.7.3 3 3 0 0 0-.9 2.2 5.2 5.2 0 0 0 1.1 2.8 11.9 11.9 0 0 0 4.6 4c1.7.7 2.4.8 3.2.7.5-.1 1.5-.6 1.8-1.2.2-.6.2-1.1.1-1.2l-.5-.2z"/></svg>`
};

/* The server owns cart validation, prices, stock, taxes and payment processing. */
let krReady = false;
let krNonce = '';
let krCartKeys = {};
let krPending = Promise.resolve();
async function krApi(path = '', body) {
  const response = await fetch(KR_WOO.api + 'cart' + path, {
    method: body ? 'POST' : 'GET', credentials: 'same-origin', cache: 'no-store',
    headers: {'Content-Type':'application/json', ...(krNonce ? {Nonce:krNonce} : {})},
    ...(body ? {body:JSON.stringify(body)} : {})
  });
  const nonce = response.headers.get('Nonce'); if (nonce) krNonce = nonce;
  const json = await response.json();
  if (!response.ok) throw new Error(new DOMParser().parseFromString(json.message || 'Impossibile aggiornare il carrello.', 'text/html').body.textContent);
  return json;
}
function krHydrate(data) {
  const next = {}, keys = {};
  for (const item of data.items || []) {
    for (const product of P) {
      const vi = (product.wc_variants || []).findIndex(v => v.id === item.id);
      if (vi >= 0) {
        const key = product.id + '|' + vi;
        next[key] = item.quantity; keys[key] = item.key;
        product.v[vi][1] = Number(item.prices.price) / (10 ** item.prices.currency_minor_unit);
        break;
      }
    }
  }
  cart = next; krCartKeys = keys; syncCart();
  if ($('#drawer').classList.contains('on')) renderDrawer();
}
async function krInitCart() {
  try { krHydrate(await krApi()); krReady = true; }
  catch (error) { toast('Carrello non disponibile. Riprova tra poco.'); }
}
function krSetQuantity(key, quantity) {
  if (!krReady) { toast('Caricamento del carrello in corso. Riprova tra un momento.'); return; }
  const [id, index] = key.split('|'), product = byId[id], variant = product?.wc_variants?.[+index];
  if (!variant?.id || !variant.available) { toast('Prodotto non disponibile per l’acquisto online.'); return; }
  const q = Math.max(0, Math.min(99, Number(quantity) || 0));
  if (q) cart[key] = q; else delete cart[key];
  syncCart();
  krPending = krPending.then(async () => {
    let data;
    if (krCartKeys[key]) data = await krApi(q ? '/update-item' : '/remove-item', {key:krCartKeys[key], ...(q ? {quantity:q} : {})});
    else if (q) data = await krApi('/add-item', {id:variant.id, quantity:q, variation:variant.variation || []});
    if (data) krHydrate(data);
  }).catch(async error => {
    try { krHydrate(await krApi()); } catch (_) { krReady = false; }
    toast(error.message);
  });
}
async function krCheckout() {
  const button = $('#toCheckout'); if (button) button.disabled = true;
  try {
    await krPending;
    if (!krReady) throw new Error('Il carrello non è disponibile. Ricarica la pagina.');
    const data = await krApi();
    if (!(data.items || []).length) throw new Error('Il carrello è vuoto.');
    location.assign(KR_WOO.checkout);
  } catch (error) { toast(error.message); if (button) button.disabled = false; }
}

/* ================= cart ================= */
let cart = {};
for(const k of Object.keys(cart)){ const [id,vi]=k.split("|"); if(!byId[id]||!byId[id].v[+vi]||!byId[id].stock||!(cart[k]>0)) delete cart[k]; }
const save = () => {};
const cartQty = () => Object.values(cart).reduce((a,b)=>a+b,0);
const lineP = k => { const [id,vi]=k.split("|"); return byId[id].v[+vi][1]; };
const cartSub = () => Object.entries(cart).reduce((a,[k,q])=>a+lineP(k)*q,0);
function setQty(key,q){ krSetQuantity(key,q); }

/* ================= rendering helpers ================= */
function ctl(key, stock=true){
  if(!stock) return `<span class="ctl off">${t("oos")}</span>`;
  const q=cart[key]||0;
  return `<div class="ctl" data-key="${key}" data-q="${q}"><button class="dec" type="button" tabindex="${q?0:-1}" aria-label="−">${ICON.minus}</button><output class="num">${digits(q)}</output><button class="inc" type="button" aria-label="${t("add")}">${ICON.plus}<span class="addl">${t("add")}</span></button></div>`;
}
function priceHtml(p){
  if(p.noprice) return `<b style="font-size:13px;color:var(--muted,#888)">${lang==="fa"?"قیمت به‌زودی":lang==="en"?"Price coming soon":"Prezzo da definire"}</b><small>&nbsp;</small>`;
  const v=p.v[vIdx(p)], kg=v[0]?v[1]/(v[0]/1000):null;
  return `<b class="num">${money(v[1])}</b>${kg?`<small class="num">${money(kg)}${t("perKg")}</small>`:`<small>&nbsp;</small>`}`;
}
function segHtml(p){
  if(p.v.length<2) return `<div class="size">${p.v[0][0]?esc(sizeLbl(p.v[0][0])):"&nbsp;"}</div>`;
  return `<div class="seg" role="group" aria-label="${t("size")}"><span class="ind" aria-hidden="true"></span>${p.v.map((v,i)=>`<button type="button" data-var="${p.id}" data-vi="${i}" aria-pressed="${i===vIdx(p)}">${esc(sizeLbl(v[0]))}</button>`).join("")}</div>`;
}
const altName = p => lang==="fa" ? `<div class="alt" lang="it">${esc(p.it)}</div>` : `<div class="alt" lang="fa">${esc(p.fa)}</div>`;
function card(p,i=0){
  return `<article class="card${p.stock?"":" oos"}" data-id="${p.id}" style="--i:${i}">
    ${!p.stock?`<span class="badge oos">${t("oos")}</span>`:p.origine?`<span class="badge orig">${esc(L(p.origine))}</span>`:""}
    <button class="thumb" type="button" data-open="${p.id}" aria-label="${esc(L(p))}" tabindex="-1">${media(p)}</button>
    <button class="name" type="button" data-open="${p.id}">${esc(L(p))}</button>
    ${altName(p)}
    ${segHtml(p)}
    <div class="price-row"><div class="price">${priceHtml(p)}</div>${p.stock&&!p.noprice&&p.wc_variants?.[vIdx(p)]?.available?ctl(keyOf(p)):""}</div>
  </article>`;
}
function placeInd(group){
  const ind=group.querySelector(".ind"), on=group.querySelector('[aria-pressed="true"]'); if(!ind||!on) return;
  ind.style.width=on.offsetWidth+"px"; ind.style.transform=`translateX(${on.offsetLeft}px)`;
}
const placeAll = () => { $$(".seg").forEach(placeInd); placeInd($("#langSw")); };

/* ================= views ================= */
let state = {view:"home", cat:null, q:""};
function renderRail(){
  $("#rail").innerHTML = CATS.map(c=>{const n=inCat(c.id).length;return `<button class="cat" type="button" data-cat="${c.id}" aria-pressed="${state.cat===c.id}"><span class="disc">${catIcon(c.id)}${n?`<span class="n num">${digits(n)}</span>`:""}</span><span class="lbl">${esc(L(c))}</span></button>`}).join("");
}
function shelf(id,title,sub,items){
  return `<section class="shelf reveal" data-shelf="${id}"><div class="shelf-head"><h3>${esc(title)}${sub?`<small>${esc(sub)}</small>`:""}</h3>
    <div class="shelf-tools"><button class="navbtn" type="button" data-scroll="-1" aria-label="${t("prev")}">${ICON.left}</button><button class="navbtn" type="button" data-scroll="1" aria-label="${t("next")}">${ICON.right}</button><button class="linkbtn" type="button" data-cat="${id}">${t("seeAll")} ${ICON.arrow}</button></div></div>
    <div class="track">${items.map(card).join("")}</div></section>`;
}
function isOpen(){ try{ const h=+new Intl.DateTimeFormat("en-GB",{hour:"numeric",hourCycle:"h23",timeZone:"Europe/Rome"}).format(new Date()); return h>=8&&h<22; }catch(e){ const h=new Date().getHours(); return h>=8&&h<22; } }
function mapArt(){
  return `<svg viewBox="0 0 600 400" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <g style="fill:var(--map-park)"><rect x="235" y="30" width="110" height="64" rx="12"/><rect x="420" y="250" width="74" height="58" rx="12"/><rect x="70" y="285" width="60" height="40" rx="10"/></g>
    <g fill="none" stroke-linecap="round" style="stroke:var(--surface)">
      <path d="M-20 250 C120 230 240 215 620 175" stroke-width="22"/>
      <path d="M150 -20 C170 120 185 260 210 420" stroke-width="12"/>
      <path d="M380 -20 C370 120 395 260 360 420" stroke-width="12"/>
      <path d="M-20 110 L620 130" stroke-width="9"/><path d="M-20 345 L620 335" stroke-width="9"/>
      <path d="M520 -20 L470 420" stroke-width="7"/><path d="M60 -20 L40 420" stroke-width="7"/>
    </g>
    <path d="M-20 250 C120 230 240 215 620 175" fill="none" stroke-width="3" stroke-dasharray="1 10" stroke-linecap="round" style="stroke:var(--saffron)"/>
    <text x="400" y="203" font-family="Figtree,sans-serif" font-size="13" font-weight="700" transform="rotate(-4 400 203)" style="fill:var(--muted)">Via Lamarmora</text><text x="290" y="68" text-anchor="middle" font-family="Figtree,sans-serif" font-size="12" font-weight="700" style="fill:var(--leaf)">Piazza Vittorio</text>
    <g transform="translate(300 214)">
      <circle r="20" style="fill:var(--pom)" opacity=".2"><animate attributeName="r" values="14;44;14" dur="2.6s" repeatCount="indefinite"/><animate attributeName="opacity" values=".35;0;.35" dur="2.6s" repeatCount="indefinite"/></circle>
      <path d="M0 0c-14-16-22-26-22-37a22 22 0 0 1 44 0c0 11-8 21-22 37z" style="fill:var(--pom)" transform="translate(0 -4)"/>
      <circle cy="-41" r="8" fill="#fff"/>
    </g></svg>`;
}
function storefront(){
  return `<svg viewBox="0 0 180 150" aria-hidden="true"><rect x="20" y="40" width="140" height="110" fill="#1d3a8a"/><path d="M14 40h152l-8-22H22z" fill="#c8102e"/><g fill="#fff" opacity=".9"><path d="M22 40h19l3 10H22z"/><path d="M60 40h19l2 10H61z"/><path d="M98 40h20l1 10H99z"/><path d="M137 40h21l-1 10h-20z"/></g>
  <path d="M40 150V100a20 20 0 0 1 40 0v50z" fill="#14295f"/><path d="M46 150v-48a14 14 0 0 1 28 0v48" fill="none" stroke="#f2a20c" stroke-width="3"/><rect x="96" y="86" width="50" height="40" rx="4" fill="#fff4dc"/><g fill="#f2a20c"><circle cx="108" cy="112" r="5"/><circle cx="121" cy="108" r="6"/><circle cx="134" cy="113" r="5"/></g></svg>`;
}
function shipArt(){
  return `<svg viewBox="0 0 200 200" aria-hidden="true"><g transform="translate(24 46)"><rect x="0" y="30" width="96" height="70" rx="8" fill="#2a1c00"/><path d="M96 48h34l22 26v26H96z" fill="#2a1c00"/><rect x="104" y="54" width="24" height="18" rx="3" fill="#ffd27a"/><circle cx="28" cy="104" r="14" fill="#fff4dc" stroke="#2a1c00" stroke-width="6"/><circle cx="124" cy="104" r="14" fill="#fff4dc" stroke="#2a1c00" stroke-width="6"/>
  <rect x="14" y="0" width="54" height="40" rx="5" fill="#c8102e"/><path d="M14 14h54" stroke="#fff" stroke-width="3" opacity=".7"/><rect x="34" y="0" width="14" height="40" fill="#fff" opacity=".35"/></g><g stroke="#2a1c00" stroke-width="5" stroke-linecap="round" opacity=".35"><path d="M2 110h20M8 126h14M0 142h18"/></g></svg>`;
}
function storeBlock(){
  const maps=SHOP.maps;
  return `<section class="store reveal" id="store"><div class="map">${mapArt()}</div>
    <div class="store-info"><h3>${t("storeT")}</h3>
      <div class="kvs">
        <div class="kv">${ICON.pin}<div><small>${t("addr")}</small><span dir="ltr">${esc(SHOP.indirizzo)}</span></div><button class="copybtn" type="button" data-copy="${esc(SHOP.indirizzo)}">${t("copy")}</button></div>
        <div class="kv">${ICON.clock}<div><small>${t("hours")}</small>${t("everyDay")}</div><span></span></div>
        <div class="kv">${ICON.phone}<div><small>${t("phone")}</small><a href="tel:${SHOP.telefono.replace(/\s/g,"")}" dir="ltr">${esc(SHOP.telefono)}</a></div><button class="copybtn" type="button" data-copy="${esc(SHOP.telefono)}">${t("copy")}</button></div>
        <div class="kv">${ICON.phone}<div><small>${t("phone2")}</small><a href="tel:${SHOP.telefono2.replace(/\s/g,"")}" dir="ltr">${esc(SHOP.telefono2)}</a></div><button class="copybtn" type="button" data-copy="${esc(SHOP.telefono2)}">${t("copy")}</button></div>
        <div class="kv">${ICON.mail}<div><small>${t("email")}</small><span dir="ltr">${esc(SHOP.email)}</span></div><button class="copybtn" type="button" data-copy="${esc(SHOP.email)}">${t("copy")}</button></div>
      </div>
      <div class="btnrow"><a class="btn primary" href="${maps}" target="_blank" rel="noopener">${ICON.pin} ${t("maps")}</a></div>
    </div></section>`;
}
const promoMedia = p => media({...p,img:p.promo_img || p.img});
function renderHome(){
  const pist=["KR005","KR003","KR004"].map(id=>byId[id]);
  const zer=byId.KR009, ahmad=byId.KR010, open=isOpen();
  const slide=(cls,art,e,h,p,cta)=>`<div class="slide ${cls}" aria-roledescription="slide">${art}<div class="copy"><span class="eyebrow" style="--d:0">${t(e)}</span><h2 style="--d:1">${t(h)}</h2><p style="--d:2">${t(p)}</p>${cta}</div></div>`;
  $("#view").innerHTML = `
  <div class="hero">
    <div class="carousel" id="car" aria-roledescription="carousel">
      <div class="slides" id="slides">
        ${slide("is-active",`<canvas id="girih" aria-hidden="true"></canvas><div class="trio">${["KR001","KR004","KR008"].map(id=>`<div>${promoMedia(byId[id])}</div>`).join("")}</div>`,"s1e","s1t","s1p",`<button class="cta" style="--d:3" type="button" data-cat="fruttasecca">${t("s1c")} ${ICON.arrow}</button>`)}
        ${slide("s-pist",`<div class="trio">${pist.map(p=>`<div>${promoMedia(p)}</div>`).join("")}</div>`,"s2e","s2t","s2p",`<button class="cta" style="--d:3" type="button" data-cat="fruttasecca">${t("s2c")} ${ICON.arrow}</button>`)}
        ${slide("s-zer",`<div class="art">${promoMedia(zer)}</div>`,"s3e","s3t","s3p",`<button class="cta" style="--d:3" type="button" data-open="${zer.id}">${t("s3c")} ${ICON.arrow}</button>`)}
        ${slide("s-ship",`<div class="art">${shipArt()}</div>`,"s4e","s4t","s4p",`<button class="cta" style="--d:3" type="button" data-info="1">${t("s4c")} ${ICON.arrow}</button>`)}
      </div>
      <div class="car-ui"><div class="dots" id="dots">${[0,1,2,3].map(i=>`<button class="dot" type="button" data-slide="${i}" aria-label="${digits(i+1)} / ${digits(4)}" aria-current="${i===0}"><i></i></button>`).join("")}</div>
        <div class="arrows"><button type="button" data-car="-1" aria-label="${t("prev")}">${ICON.left}</button><button type="button" data-car="1" aria-label="${t("next")}">${ICON.right}</button></div></div>
    </div>
    <div class="hero-side">
      <button class="tile t-tea" type="button" data-cat="te"><span class="pic">${promoMedia(ahmad)}</span><span class="eyebrow">${t("teaE")}</span><h3>${t("teaT")}</h3><span class="go">${t("go")} ${ICON.arrow}</span></button>
      <a class="tile t-shop" href="#store" data-store="1"><span class="storefront">${storefront()}</span><span class="eyebrow">${t("shopE")}</span><h3>${t("shopT")}</h3><span class="open${open?"":" closed"}"><i></i>${open?t("openNow"):t("closedNow")}</span></a>
    </div>
  </div>
  <div class="facts">
    ${[["pin","f1","f1s"],["clock","f2","f2s"],["truck","f3","f3s"],["ret","f4","f4s"]].map(([ic,a,b])=>`<div class="fact">${ICON[ic]}<p><b>${t(a)}</b>${t(b)}</p></div>`).join("")}
  </div>
  ${shelf("fruttasecca",t("dried"),t("driedSub"),inCat("fruttasecca"))}
  ${shelf("te",t("tea"),t("teaSub"),inCat("te"))}
  <section class="instore reveal"><div><h3>${t("instoreT")}</h3><p>${t("instoreP")}</p></div>
    <div class="mini-cats">${CATS.filter(c=>!inCat(c.id).length).map(c=>`<button class="mc" type="button" data-cat="${c.id}">${catIcon(c.id)}<span>${esc(L(c))}</span></button>`).join("")}</div></section>
  ${storeBlock()}`;
  initCarousel(); initShelves();
}
function renderCats(){
  $("#view").innerHTML = `<div class="results-head"><h3>${t("allCats")}</h3></div>
   <div class="catgrid">${CATS.map((c,i)=>{const n=inCat(c.id).length;return `<button class="ctile" type="button" data-cat="${c.id}" style="--i:${i}"><span class="disc">${catIcon(c.id)}</span><span><b>${esc(L(c))}</b>${n?`<small class="on">${digits(n)} ${t("products")} ${t("online")}</small>`:`<small>${t("inStore")}</small>`}</span></button>`}).join("")}</div>`;
}
const norm = s => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g,"");
function matches(p,q){ const c=catById(p.cat); const s=norm([p.it,p.en,p.fa,c.it,c.en,c.fa].join(" ")); return norm(q).split(/\s+/).filter(Boolean).every(w=>s.includes(w)); }
function renderList(){
  const q=state.q.trim();
  let items = state.cat ? inCat(state.cat) : P;
  if(q) items = items.filter(p=>matches(p,q));
  const c = catById(state.cat);
  const title = q ? `${t("results")} “${esc(q)}”` : c ? esc(L(c)) : t("allProducts");
  const chips = `<div class="chips" id="chips"><button class="chip" type="button" data-cat="" aria-pressed="${!state.cat}">${t("all")}</button>${CATS.map(cc=>`<button class="chip" type="button" data-cat="${cc.id}" aria-pressed="${state.cat===cc.id}">${esc(L(cc))}</button>`).join("")}</div>`;
  let body;
  if(items.length) body=`<div class="grid">${items.map((p,i)=>card(p,i)).join("")}</div>`;
  else if(c && !q) body=`<div class="empty"><span class="disc">${catIcon(c.id)}</span><h4>${t("emptyCatT")}</h4><p>${t("emptyCatP")}</p><div class="btnrow" style="justify-content:center"><button class="btn primary" type="button" data-store="1">${ICON.pin} ${t("goStore")}</button><a class="btn ghost" href="tel:${SHOP.telefono.replace(/\s/g,"")}" dir="ltr">${ICON.phone} ${esc(SHOP.telefono)}</a></div></div>`;
  else body=`<div class="empty"><h4>${t("noRes")}</h4></div>`;
  $("#view").innerHTML = `<div class="results-head"><h3>${title} <span class="count num">· ${digits(items.length)}</span></h3></div>${chips}${body}`;
  const ch=$("#chips"), on=ch.querySelector('[aria-pressed="true"]');
  if(on){ ch.style.scrollBehavior="auto"; ch.scrollLeft = on.offsetLeft - ch.clientWidth/2 + on.offsetWidth/2; ch.style.scrollBehavior=""; }
}
function renderFooter(){
  $("#footCols").innerHTML = `
   <div><div class="logo-text" style="font-size:26px">Kabul Roma<small style="height:auto">کابل روما</small></div><p class="about">${t("fAbout")}</p></div>
   <div><h5>${t("fShop")}</h5><ul>${CATS.slice(0,5).map(c=>`<li><button type="button" data-cat="${c.id}">${esc(L(c))}</button></li>`).join("")}<li><button type="button" data-nav="cats">${t("fAllCats")}</button></li></ul></div>
   <div><h5>${t("fContact")}</h5><ul><li><span dir="ltr">${esc(SHOP.indirizzo)}</span></li><li>${t("everyDay")}</li><li><span dir="ltr">${esc(SHOP.telefono)}</span></li><li><span dir="ltr">${esc(SHOP.telefono2)}</span></li><li><span dir="ltr">${esc(SHOP.email)}</span></li></ul></div>
   <div><h5>${t("fHelp")}</h5><ul><li><button type="button" data-info="1">${t("fShipRet")}</button></li><li><button type="button" data-store="1">${t("goStore")}</button></li></ul></div>`;
}
function renderLegal(){
  const items=[[t("vat"),SHOP.piva],[t("rea"),SHOP.rea],[t("shareCap"),SHOP.capitale],[t("regOffice"),SHOP.sede_legale]];
  $("#legalBar").innerHTML=`<span><bdi dir="ltr">© 2026 ${esc(SHOP.ragione_sociale)} · kabulroma.com</bdi></span><span class="legal-data">${items.map(([k,v])=>`<span class="li">${esc(k)} <bdi dir="ltr">${esc(v)}</bdi></span>`).join(" · ")}</span>`;
}
function setNav(){
  const cur = state.view==="home" ? "home" : state.view==="search" ? "search" : "cats";
  $$("nav.bottom [data-nav]").forEach(b=>b.setAttribute("aria-current",String(b.dataset.nav===cur)));
}
function render(){
  renderRail();
  if(state.view==="home") renderHome();
  else if(state.view==="cats") renderCats();
  else renderList();
  placeAll(); setNav();
}
function vt(fn){ if(!document.startViewTransition||REDUCED){ fn(); return; } try{ const v=document.startViewTransition(fn); v.ready.catch(()=>{}); v.finished.catch(()=>{}); v.updateCallbackDone.catch(()=>{}); }catch(e){ fn(); } }
function go(view,cat=null,keepQ=false){
  const run=()=>{
    state.view=view; state.cat=cat;
    if(!keepQ){ state.q=""; $("#q").value=""; $("#searchBox").classList.remove("has-q"); }
    render();
  };
  vt(run);
  const top=$("#main").getBoundingClientRect().top+scrollY-90;
  if(scrollY>top) scrollTo({top:Math.max(0,top),behavior:REDUCED?"auto":"smooth"});
}

/* ================= carousel ================= */
const CAR={i:0,n:4,drag:null,justDragged:0};
let carVisible=true;
const carIO="IntersectionObserver" in window ? new IntersectionObserver(es=>es.forEach(e=>carVisible=e.isIntersecting)) : null;
function initCarousel(){
  const car=$("#car"); if(!car) return;
  showSlide(0,true); pauseCar(REDUCED);
  if(carIO){ carIO.disconnect(); carIO.observe(car); }
  car.addEventListener("pointerenter",e=>{ if(e.pointerType==="mouse") pauseCar(true); });
  car.addEventListener("pointerleave",e=>{ if(e.pointerType==="mouse") pauseCar(false); });
  car.addEventListener("focusin",e=>{ let kb=true; try{ kb=e.target.matches(":focus-visible"); }catch(_){} if(kb) pauseCar(true); });
  car.addEventListener("focusout",()=>pauseCar(false));
  const sl=$("#slides");
  sl.addEventListener("pointerdown",e=>{ if(e.button!==0) return; CAR.drag={x:e.clientX,y:e.clientY,dx:0,w:car.clientWidth,id:e.pointerId,moved:false}; });
  sl.addEventListener("pointermove",e=>{
    const d=CAR.drag; if(!d||d.id!==e.pointerId) return;
    d.dx=e.clientX-d.x;
    if(!d.moved && Math.abs(d.dx)>8 && Math.abs(d.dx)>Math.abs(e.clientY-d.y)){ d.moved=true; sl.classList.add("dragging"); try{sl.setPointerCapture(e.pointerId);}catch(_){} pauseCar(true); }
    if(d.moved){ const dir=document.dir==="rtl"?1:-1; const edge=(CAR.i===0&&d.dx*dir<0)||(CAR.i===CAR.n-1&&d.dx*dir>0); sl.style.transform=`translateX(${dir*CAR.i*d.w + d.dx*(edge?.35:1)}px)`; }
  });
  const end=()=>{
    const d=CAR.drag; if(!d) return; CAR.drag=null; sl.classList.remove("dragging");
    if(d.moved){ const rtl=document.dir==="rtl", thr=d.w*.14; let ni=CAR.i; if(d.dx<-thr) ni+=rtl?-1:1; else if(d.dx>thr) ni+=rtl?1:-1; showSlide(Math.max(0,Math.min(CAR.n-1,ni))); pauseCar(false); CAR.justDragged=Date.now(); }
  };
  sl.addEventListener("pointerup",end); sl.addEventListener("pointercancel",end);
  drawGirih(); cancelAnimationFrame(girihRAF); if(!REDUCED) girihLoop();
}
function showSlide(i,instant){
  const sl=$("#slides"); if(!sl) return;
  CAR.i=i;
  const dir=document.dir==="rtl"?1:-1;
  if(instant) sl.style.transition="none";
  sl.style.transform=`translateX(${dir*i*100}%)`;
  if(instant){ void sl.offsetHeight; sl.style.transition=""; }
  $$("#slides .slide").forEach((s,k)=>{ s.classList.toggle("is-active",k===i); s.setAttribute("aria-hidden",String(k!==i)); s.querySelectorAll("button").forEach(b=>b.tabIndex=k===i?0:-1); });
  $$("#dots .dot").forEach((d,k)=>{ d.setAttribute("aria-current",String(k===i)); const bar=d.querySelector("i"); bar.style.animation="none"; void bar.offsetWidth; bar.style.animation=""; });
  $("#car").classList.toggle("s-ship-active",i===3);
}
function pauseCar(p){ const c=$("#car"); if(c) c.classList.toggle("paused",p||REDUCED); }
document.addEventListener("animationend",e=>{ if(REDUCED||e.animationName!=="fill") return; if(e.target.closest(".dot[aria-current='true']")) showSlide((CAR.i+1)%CAR.n); });
document.addEventListener("visibilitychange",()=>pauseCar(document.hidden));

/* girih canvas: eight-point star lattice that breathes slowly and lights up toward the pointer */
let girihRAF=0; const girihT0=performance.now(); const glow={x:.78,y:.35,tx:.78,ty:.35};
function girihLoop(){ if(!$("#girih")) return; girihRAF=requestAnimationFrame(girihLoop); if(CAR.i===0 && !document.hidden && carVisible) drawGirih(); }
function drawGirih(){
  const cv=$("#girih"); if(!cv) return;
  const r=cv.getBoundingClientRect(); if(!r.width) return;
  const dpr=Math.min(2,devicePixelRatio||1);
  if(cv.width!==Math.round(r.width*dpr)||cv.height!==Math.round(r.height*dpr)){ cv.width=Math.round(r.width*dpr); cv.height=Math.round(r.height*dpr); }
  const x=cv.getContext("2d"); x.setTransform(dpr,0,0,dpr,0,0);
  const W=r.width,H=r.height,tm=REDUCED?0:(performance.now()-girihT0)/1000;
  glow.x+=(glow.tx-glow.x)*.06; glow.y+=(glow.ty-glow.y)*.06;
  const g=x.createLinearGradient(0,0,W,H); g.addColorStop(0,"#1d3a8a"); g.addColorStop(1,"#0f1f4d"); x.fillStyle=g; x.fillRect(0,0,W,H);
  const rg=x.createRadialGradient(glow.x*W,glow.y*H,0,glow.x*W,glow.y*H,Math.max(W,H)*.6); rg.addColorStop(0,"rgba(242,162,12,.22)"); rg.addColorStop(1,"rgba(242,162,12,0)"); x.fillStyle=rg; x.fillRect(0,0,W,H);
  const s=68; x.lineWidth=1.3;
  for(let yy=-s; yy<H+s; yy+=s){ for(let xx=-s; xx<W+s; xx+=s){
    const cx=xx+s/2, cy=yy+s/2;
    const lit=Math.max(0,1-Math.hypot(cx-glow.x*W,cy-glow.y*H)/Math.max(W,H)*1.8);
    const br=Math.sin(tm*.8+(cx+cy)*.012)*.5+.5;
    x.strokeStyle=`rgba(242,162,12,${.08+.42*lit+.08*br})`;
    const rot=tm*.05;
    x.beginPath();
    for(let k=0;k<16;k++){ const a=Math.PI*2*k/16-Math.PI/2+rot, rad=k%2?s*.2:s*(.4+.03*br); const px=cx+Math.cos(a)*rad, py=cy+Math.sin(a)*rad; k?x.lineTo(px,py):x.moveTo(px,py); }
    x.closePath(); x.stroke();
    x.strokeStyle=`rgba(255,255,255,${.035+.08*lit})`; x.strokeRect(xx+.5,yy+.5,s,s);
  }}
  const v=x.createLinearGradient(0,H*.3,0,H); v.addColorStop(0,"rgba(12,24,64,0)"); v.addColorStop(1,"rgba(12,24,64,.9)"); x.fillStyle=v; x.fillRect(0,0,W,H);
  const rtl=document.dir==="rtl", vx=x.createLinearGradient(rtl?W:0,0,rtl?W*.3:W*.7,0); vx.addColorStop(0,"rgba(12,24,64,.55)"); vx.addColorStop(1,"rgba(12,24,64,0)"); x.fillStyle=vx; x.fillRect(0,0,W,H);
}
document.addEventListener("pointermove",e=>{ const cv=$("#girih"); if(!cv) return; const r=cv.getBoundingClientRect(); if(e.clientY<r.top||e.clientY>r.bottom||e.clientX<r.left||e.clientX>r.right) return; glow.tx=(e.clientX-r.left)/r.width; glow.ty=(e.clientY-r.top)/r.height; },{passive:true});

/* ================= shelves ================= */
function initShelves(){
  $$("[data-shelf]").forEach(sec=>{
    const tr=sec.querySelector(".track"), [pv,nx]=sec.querySelectorAll("[data-scroll]");
    const upd=()=>{ const max=tr.scrollWidth-tr.clientWidth-2, sl=Math.abs(tr.scrollLeft); pv.disabled=sl<=2; nx.disabled=sl>=max; };
    tr.addEventListener("scroll",upd,{passive:true}); upd();
  });
}

/* ================= 3D tilt on product art (mouse only) ================= */
if(HOVER && !REDUCED){
  let tilted=null;
  document.addEventListener("pointermove",e=>{
    const th=e.target.closest ? e.target.closest(".card .thumb") : null;
    if(tilted && tilted!==th){ tilted.classList.remove("tilting"); tilted.firstElementChild.style.transform=""; tilted=null; }
    if(!th) return;
    const r=th.getBoundingClientRect(), px=(e.clientX-r.left)/r.width-.5, py=(e.clientY-r.top)/r.height-.5;
    th.classList.add("tilting"); tilted=th;
    th.firstElementChild.style.transform=`rotateX(${(-py*12).toFixed(2)}deg) rotateY(${(px*14).toFixed(2)}deg) scale(1.06)`;
  },{passive:true});
}

/* ================= cart sync & motion ================= */
function syncCart(){
  const q=cartQty(), s=cartSub();
  $("#cartCount").textContent=digits(q);
  const cs=$("#cartSum"); cs.hidden=!q; cs.textContent=q?money(s):"";
  const dot=$("#navDot"); dot.hidden=!q; dot.textContent=digits(q);
  $$(".ctl[data-key]").forEach(el=>{
    const nq=cart[el.dataset.key]||0;
    if(nq!==+el.dataset.q){ el.dataset.q=nq; const o=el.querySelector("output"); o.textContent=digits(nq); o.classList.remove("pop"); void o.offsetWidth; if(nq) o.classList.add("pop"); el.querySelector(".dec").tabIndex=nq?0:-1; }
  });
  if($("#drawer").classList.contains("on") && drawerMode==="cart"){ const a=$("#tSub"); if(a){ a.textContent=money(s); $("#tTot").textContent=money(s); } if(!q) renderDrawer(); }
}
function bump(el){ if(!el||REDUCED) return; el.classList.remove("bump"); void el.offsetWidth; el.classList.add("bump"); }
const cartTarget = () => innerWidth<=640 ? $("#navCart") : $("#cartBtn");
function flyToCart(fromEl){
  const target=cartTarget(), svg=fromEl&&fromEl.querySelector("img,svg");
  if(REDUCED||!svg){ bump(target); return; }
  const r=svg.getBoundingClientRect(), tr=target.getBoundingClientRect();
  if(!r.width){ bump(target); return; }
  const size=Math.min(r.width,r.height,150);
  const fl=document.createElement("div"); fl.className="flyer"; fl.appendChild(svg.cloneNode(true));
  fl.firstElementChild.style.transform="";
  Object.assign(fl.style,{left:(r.left+r.width/2-size/2)+"px",top:(r.top+r.height/2-size/2)+"px",width:size+"px",height:size+"px"});
  document.body.appendChild(fl);
  const dx=tr.left+tr.width/2-(r.left+r.width/2), dy=tr.top+tr.height/2-(r.top+r.height/2);
  const a=fl.animate([
    {transform:"translate(0,0) scale(1) rotate(0)",opacity:1},
    {transform:`translate(${dx*.42}px,${dy*.42-90}px) scale(.6) rotate(-10deg)`,opacity:1,offset:.45},
    {transform:`translate(${dx}px,${dy}px) scale(.12) rotate(8deg)`,opacity:.4}
  ],{duration:720,easing:"cubic-bezier(.45,0,.25,1)"});
  a.onfinish=()=>{ fl.remove(); bump(target); };
}
function addOne(key,srcEl){
  const was=cart[key]||0; setQty(key,was+1);
  if(!was){ const [id,vi]=key.split("|"), p=byId[id], v=p.v[+vi]; toast(`${t("added")}: ${L(p)}${v[0]?" · \u2068"+sizeLbl(v[0])+"\u2069":""}`); flyToCart(srcEl); }
  else bump(cartTarget());
}

/* ================= drawer ================= */
let drawerMode="cart", lastOrder="";
const form={name:"",phone:"",how:"ship",addr:"",notes:""};
function lineHtml(k){
  const [id,vi]=k.split("|"), p=byId[id], v=p.v[+vi];
  return `<div class="line" data-line="${k}"><div class="mini">${p.img?media(p):pack(p,+vi)}</div><div style="min-width:0"><h4>${esc(L(p))}</h4><small>${v[0]?esc(sizeLbl(v[0]))+" · ":""}${money(v[1])}</small></div>${ctl(k)}</div>`;
}
const closeBtn = () => `<button class="x close" type="button" data-close aria-label="${t("close")}">${ICON.x}</button>`;
function renderDrawer(){
  const body=$("#drawerBody"), foot=$("#drawerFoot"), keys=Object.keys(cart);
  body.scrollTop=0;
  $("#drawer .drawer-head .x").setAttribute("aria-label",t("close"));
  if(drawerMode==="cart"){
    $("#drawerTitle").textContent=t("yourCart");
    if(!keys.length){
      body.innerHTML=`<div class="empty step"><span class="disc">${catIcon("fruttasecca")}</span><h4>${t("emptyCart")}</h4><p>${t("emptyCartP")}</p></div>`;
      foot.innerHTML=`<button class="btn primary block" type="button" data-cat="fruttasecca">${t("startShop")} ${ICON.arrow}</button>`; return;
    }
    body.innerHTML=`<div class="step" style="display:grid;gap:10px">${keys.map(lineHtml).join("")}<div class="note">${ICON.info}<span>${t("orderNote")}</span></div></div>`;
    foot.innerHTML=`<div class="totals"><div><span>${t("subtotal")}</span><span id="tSub">${money(cartSub())}</span></div><div><span>${t("shipping")}</span><span>${t("shipTbd")}</span></div><div class="grand"><span>${t("total")}</span><span id="tTot">${money(cartSub())}</span></div></div>
      <button class="btn primary block" type="button" id="toCheckout">${t("checkout")} ${ICON.arrow}</button>`;
  } else if(drawerMode==="checkout"){
    $("#drawerTitle").textContent=t("checkout");
    body.innerHTML=`<form id="coForm" class="step" style="display:grid;gap:14px" novalidate>
      <label class="field" id="fwName" for="fName">${t("name")}<input id="fName" autocomplete="name" value="${esc(form.name)}"></label>
      <label class="field" id="fwPhone" for="fPhone">${t("phoneF")}<input id="fPhone" type="tel" autocomplete="tel" inputmode="tel" dir="ltr" value="${esc(form.phone)}"></label>
      <div class="field">${t("how")}<div class="radio2"><button type="button" data-how="ship" aria-pressed="${form.how==="ship"}">${t("ship")}<small>${t("shipS")}</small></button><button type="button" data-how="pickup" aria-pressed="${form.how==="pickup"}">${t("pickup")}<small>${t("pickupS")}</small></button></div></div>
      <div class="collapse${form.how==="ship"?"":" shut"}" id="addrWrap"><div><label class="field" id="fwAddr" for="fAddr">${t("address")}<input id="fAddr" autocomplete="street-address" placeholder="${t("addrPh")}" value="${esc(form.addr)}"></label></div></div>
      <label class="field" for="fNotes">${t("notes")}<textarea id="fNotes">${esc(form.notes)}</textarea></label>
      <p id="coErr" style="color:var(--pom);margin:0;font-weight:700" hidden>${t("required")}</p>
    </form>`;
    foot.innerHTML=`<div class="totals"><div class="grand"><span>${t("total")}</span><span>${money(cartSub())}</span></div></div>
      <button class="btn primary block" type="submit" form="coForm">${t("review")} ${ICON.arrow}</button><button class="btn link block" type="button" data-dmode="cart">${t("back")}</button>`;
  } else {
    $("#drawerTitle").textContent=t("orderReady");
    const wa="https://wa.me/"+SHOP.telefono_wa+"?text="+encodeURIComponent(lastOrder);
    body.innerHTML=`<div class="step" style="display:grid;gap:14px"><div class="okmark"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg></div>
      <p style="margin:0;color:var(--muted);text-align:center">${t("orderReadyP")}</p><div class="summary" id="sumText" dir="ltr">${esc(lastOrder)}</div></div>`;
    foot.innerHTML=`<a class="btn wa block" href="${wa}" target="_blank" rel="noopener">${ICON.wa} ${t("sendWa")}</a>
      <button class="btn ghost block" type="button" id="copyOrder">${t("copyText")}</button>
      <button class="btn link block" type="button" data-dmode="cart">${t("back")}</button>`;
  }
}
function buildOrder(){
  const lines=Object.entries(cart).map(([k,q])=>{const [id,vi]=k.split("|"),p=byId[id],v=p.v[+vi];return `• ${q} × ${p.it}${v[0]?" ("+sizeIt(v[0])+")":""} — ${moneyIt(v[1]*q)}  [${id}]`});
  return `Ordine dal sito Kabul Roma\n\n${lines.join("\n")}\n\nTotale prodotti: ${moneyIt(cartSub())}\nSpedizione: da confermare\n\nNome: ${form.name.trim()}\nTelefono: ${form.phone.trim()}\nConsegna: ${form.how==="ship"?"Spedizione":"Ritiro in negozio"}${form.how==="ship"?`\nIndirizzo: ${form.addr.trim()}`:""}${form.notes.trim()?`\nNote: ${form.notes.trim()}`:""}`;
}
let lastFocus=null;
let locked=false, lockY=0;
function lock(on){
  if(on===locked) return; locked=on; const b=document.body, h=document.documentElement;
  const pin=TOUCH; /* iOS Safari ignores overflow:hidden for touch scrolling, so pin the body there */
  if(on){ lockY=scrollY; h.style.overflow="hidden"; if(pin) Object.assign(b.style,{position:"fixed",top:-lockY+"px",left:"0",right:"0",width:"100%"}); }
  else { h.style.overflow=""; if(pin){ Object.assign(b.style,{position:"",top:"",left:"",right:"",width:""}); const sb=h.style.scrollBehavior; h.style.scrollBehavior="auto"; scrollTo(0,lockY); h.style.scrollBehavior=sb; } }
}
function openDrawer(mode="cart"){
  closeModal(true); lastFocus=document.activeElement;
  drawerMode=mode; renderDrawer();
  const d=$("#drawer"); d.classList.add("on"); d.setAttribute("aria-hidden","false"); $("#scrim").classList.add("on"); lock(true);
  if(!TOUCH) setTimeout(()=>d.querySelector(".x").focus({preventScroll:true}),80);
}
function closeDrawer(){
  const d=$("#drawer"); if(!d.classList.contains("on")) return;
  d.classList.remove("on"); d.setAttribute("aria-hidden","true");
  if(!$("#modal").classList.contains("on")){ $("#scrim").classList.remove("on"); lock(false); }
  lastFocus?.focus?.({preventScroll:true});
}

/* ================= product modal ================= */
let modalQty=1, modalP=null;
function modalHtml(p){
  const v=p.v[vIdx(p)], c=catById(p.cat), kg=v[0]?v[1]/(v[0]/1000):null;
  return `${closeBtn()}
   <div class="pic">${media(p)}</div>
   <div class="info">
     <button class="chip" type="button" data-cat="${c.id}" style="align-self:flex-start">${esc(L(c))}</button>
     <h3 id="mTitle">${esc(L(p))}</h3>
     ${lang==="fa"?`<div class="alt2 alt" lang="it">${esc(p.it)}</div>`:`<div class="alt2 alt" lang="fa">${esc(p.fa)}</div>`}
     <p class="desc">${esc(L(p.d))}</p>
     ${p.v.length>1?segHtml(p):""}
     <div class="bigprice"><b>${p.noprice?t("inStore"):money(v[1])}</b>${kg?`<small>${money(kg)}${t("perKg")}</small>`:""}</div>
     <div class="specs">${v[0]?`<span>${t("size")}</span><b>${esc(sizeLbl(v[0]))}</b>`:""}${p.origine?`<span>${t("origin")}</span><b>${esc(L(p.origine))}</b>`:""}${p.importatore?`<span>${t("importer")}</span><b>${t("impVal")}</b>`:""}<span>${t("avail")}</span><b style="color:${p.stock?"var(--leaf)":"var(--pom)"}">${p.stock?t("yes"):t("oos")}</b><span>${t("code")}</span><b>${p.id}</b></div>
     <div class="buy">${p.stock&&!p.noprice&&p.wc_variants?.[vIdx(p)]?.available?`<div class="qty"><button type="button" data-mq="-1" aria-label="−">−</button><output id="mq" class="num">${digits(modalQty)}</output><button type="button" data-mq="1" aria-label="+">+</button></div>
       <button class="btn primary" type="button" id="mAdd" style="flex:1"><span class="long">${t("addToCart")}</span><span class="short">${t("add")} · <span class="mtot num">${money(v[1]*modalQty)}</span></span></button>`:`<button class="btn ghost block" type="button" disabled>${p.noprice?t("inStore"):t("oos")}</button>`}</div>
   </div>`;
}
function updMTot(){ const el=$("#mAdd .mtot"); if(el&&modalP) el.textContent=money(modalP.v[vIdx(modalP)][1]*modalQty); }
function openProduct(id){
  closeDrawer(); lastFocus=document.activeElement;
  modalP=byId[id]; modalQty=1;
  $("#modal").classList.remove("sheet");
  $("#modalBox").setAttribute("aria-labelledby","mTitle");
  $("#modalBox").innerHTML=modalHtml(modalP); $$("#modalBox .seg").forEach(placeInd);
  showModal();
}
function openInfo(){
  closeDrawer(); lastFocus=document.activeElement; modalP=null;
  $("#modal").classList.add("sheet");
  $("#modalBox").setAttribute("aria-labelledby","iTitle");
  $("#modalBox").innerHTML=`${closeBtn()}<div class="sheet-body"><h3 id="iTitle">${t("infoT")}</h3><h4>${t("infoShipT")}</h4><ul>${T[lang].infoShip.map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h4>${t("infoRetT")}</h4><ul>${T[lang].infoRet.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>`;
  showModal();
}
function showModal(){
  const m=$("#modal"); m.classList.add("on"); m.setAttribute("aria-hidden","false"); $("#scrim").classList.add("on"); lock(true);
  $("#modalBox").scrollTop=0;
  if(!TOUCH) setTimeout(()=>m.querySelector(".x")?.focus({preventScroll:true}),80);
}
function closeModal(silent){
  const m=$("#modal"); if(!m.classList.contains("on")) return;
  m.classList.remove("on"); m.setAttribute("aria-hidden","true");
  if(!$("#drawer").classList.contains("on")){ $("#scrim").classList.remove("on"); lock(false); }
  if(!silent) lastFocus?.focus?.({preventScroll:true});
}
const closeAll = () => { closeModal(); closeDrawer(); };

/* ================= toast & copy ================= */
let toastT;
function toast(msg){ const el=$("#toast"); el.innerHTML=`${ICON.check}<span>${esc(msg)}</span>`; el.classList.add("on"); clearTimeout(toastT); toastT=setTimeout(()=>el.classList.remove("on"),2000); }
function copyText(txt,fallbackEl){
  const fb=()=>{ if(!fallbackEl) return; const r=document.createRange(); r.selectNodeContents(fallbackEl); const s=getSelection(); s.removeAllRanges(); s.addRange(r); };
  try{ navigator.clipboard.writeText(txt).then(()=>toast(t("copied")),fb); }catch(e){ fb(); }
}

/* ================= search ================= */
let sgIdx=-1;
function hl(text,q){ const i=norm(text).indexOf(norm(q)); if(!q||i<0) return esc(text); return esc(text.slice(0,i))+"<mark>"+esc(text.slice(i,i+q.length))+"</mark>"+esc(text.slice(i+q.length)); }
function renderSuggest(){
  const q=$("#q").value.trim(), box=$("#suggest");
  $("#searchBox").classList.toggle("has-q",!!q);
  if(!q){ closeSuggest(); return; }
  const res=P.filter(p=>matches(p,q)).slice(0,6); sgIdx=-1;
  box.innerHTML = res.length ? res.map((p,i)=>`<button class="sg" type="button" role="option" id="sg${i}" data-open="${p.id}" aria-selected="false"><span class="mini">${media(p)}</span><span style="min-width:0"><b>${hl(L(p),q)}</b><small>${esc(L(catById(p.cat)))}</small></span><span class="num" style="font-weight:800">${(p.noprice?"":money(p.v[0][1]))}</span></button>`).join("")+`<button class="sg-all" type="button" id="sgAll">${t("showAll")} ${ICON.arrow}</button>`
    : `<div class="sg-none">${t("noRes")}</div>`;
  box.classList.add("on"); $("#q").setAttribute("aria-expanded","true");
}
function closeSuggest(){ $("#suggest").classList.remove("on"); $("#q").setAttribute("aria-expanded","false"); $("#q").removeAttribute("aria-activedescendant"); }
function runSearch(){ const v=$("#q").value; closeSuggest(); state.q=v; if(v.trim()) go("search",null,true); else go("home"); $("#q").blur(); }

/* ================= language ================= */
function applyLang(first){
  const run=()=>{
    document.documentElement.lang=lang;
    document.documentElement.dir=lang==="fa"?"rtl":"ltr";
    $$("[data-t]").forEach(el=>el.textContent=t(el.dataset.t));
    $$("[data-tp]").forEach(el=>el.placeholder=t(el.dataset.tp));
    $("#q").setAttribute("aria-label",t("search")); $("#qClear").setAttribute("aria-label",t("clear"));
    $$("[data-lang]").forEach(b=>b.setAttribute("aria-pressed",String(b.dataset.lang===lang)));
    try{ localStorage.setItem("kr_lang",lang); }catch(e){}
    renderFooter(); renderLegal(); render(); syncCart();
    if($("#drawer").classList.contains("on")) renderDrawer();
    if($("#modal").classList.contains("on")){ if(modalP){ $("#modalBox").innerHTML=modalHtml(modalP); $$("#modalBox .seg").forEach(placeInd); } else openInfo(); }
    if($("#suggest").classList.contains("on")) renderSuggest();
  };
  if(first) run(); else vt(run);
}

/* ================= events ================= */
document.addEventListener("click",e=>{
  const el=e.target.closest("button,a"); if(!el) return;
  if(CAR.justDragged && Date.now()-CAR.justDragged<300 && el.closest("#slides")){ e.preventDefault(); return; }
  const ctlEl=el.closest(".ctl[data-key]");
  if(ctlEl){
    const key=ctlEl.dataset.key, q=cart[key]||0;
    if(el.classList.contains("inc")){ const src=el.closest(".card")?.querySelector(".thumb")||el.closest(".spot")?.querySelector(".pic"); addOne(key, el.closest(".line")?null:src); }
    else if(el.classList.contains("dec")){
      const line=el.closest(".line");
      if(line && q===1){ line.classList.add("out"); setTimeout(()=>{ line.remove(); setQty(key,0); },220); }
      else setQty(key,q-1);
    }
    return;
  }
  if(el.dataset.var){
    const p=byId[el.dataset.var]; sel[p.id]=+el.dataset.vi;
    const seg=el.closest(".seg"); seg.querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",String(b===el))); placeInd(seg);
    const cardEl=el.closest(".card");
    if(cardEl){
      const pr=cardEl.querySelector(".price"); pr.innerHTML=priceHtml(p); pr.querySelector("b").classList.add("flip");
      const c=cardEl.querySelector(".ctl[data-key]"); if(c){ const tmp=document.createElement("div"); tmp.innerHTML=ctl(keyOf(p)); c.replaceWith(tmp.firstElementChild); }
      if(!p.img) cardEl.querySelector(".thumb").innerHTML=pack(p);
    } else if(el.closest("#modalBox")){
      const box=$("#modalBox"); box.querySelector(".bigprice").outerHTML=modalHtml(p).match(/<div class="bigprice">.*?<\/div>/s)[0];
      box.querySelector(".bigprice b").classList.add("flip");
      box.querySelector(".specs").outerHTML=modalHtml(p).match(/<div class="specs">.*?<\/b><\/div>/s)[0];
      if(!p.img) box.querySelector(".pic").innerHTML=pack(p); updMTot();
    }
    return;
  }
  if(el.dataset.open){ e.preventDefault(); closeSuggest(); openProduct(el.dataset.open); return; }
  if(el.dataset.cat!==undefined){ e.preventDefault(); closeAll(); const c=el.dataset.cat; go(c?"cat":"all",c||null); return; }
  if(el.dataset.lang){ if(el.dataset.lang!==lang){ lang=el.dataset.lang; applyLang(); } return; }
  if(el.dataset.slide){ showSlide(+el.dataset.slide); return; }
  if(el.dataset.car){ showSlide((CAR.i+(+el.dataset.car)+CAR.n)%CAR.n); return; }
  if(el.dataset.scroll){ const tr=el.closest("section").querySelector(".track"); const dir=(+el.dataset.scroll)*(document.dir==="rtl"?-1:1); tr.scrollBy({left:dir*tr.clientWidth*.85,behavior:REDUCED?"auto":"smooth"}); return; }
  if(el.dataset.info){ openInfo(); return; }
  if(el.dataset.store||el.id==="whereLink"){ e.preventDefault(); closeAll(); const toStore=()=>$("#store")?.scrollIntoView({behavior:REDUCED?"auto":"smooth",block:"start"}); if(state.view!=="home"){ go("home"); setTimeout(toStore,380); } else toStore(); return; }
  if(el.dataset.copy){ copyText(el.dataset.copy); return; }
  if(el.dataset.how){ form.how=el.dataset.how; el.parentElement.querySelectorAll("button").forEach(b=>b.setAttribute("aria-pressed",String(b===el))); $("#addrWrap").classList.toggle("shut",form.how!=="ship"); return; }
  if(el.dataset.dmode){ drawerMode=el.dataset.dmode; renderDrawer(); return; }
  if(el.hasAttribute("data-close")){ closeAll(); return; }
  if(el.dataset.mq){ modalQty=Math.max(1,Math.min(99,modalQty+(+el.dataset.mq))); const o=$("#mq"); o.textContent=digits(modalQty); updMTot(); o.classList.remove("flip"); void o.offsetWidth; o.classList.add("flip"); return; }
  if(el.id==="mAdd"){ const key=keyOf(modalP); setQty(key,(cart[key]||0)+modalQty); toast(`${t("added")}: ${L(modalP)}`); flyToCart($("#modalBox .pic")); setTimeout(()=>closeModal(),160); return; }
  if(el.id==="logoLink"){ e.preventDefault(); go("home"); scrollTo({top:0,behavior:REDUCED?"auto":"smooth"}); return; }
  if(el.id==="cartBtn"){ openDrawer("cart"); return; }
  if(el.id==="toCheckout"){ krCheckout(); return; }
  if(el.id==="copyOrder"){ copyText(lastOrder,$("#sumText")); return; }
  if(el.id==="qClear"){ $("#q").value=""; renderSuggest(); $("#q").focus(); if(state.view==="search") go("home"); return; }
  if(el.id==="sgAll"){ runSearch(); return; }
  if(el.dataset.nav){ const n=el.dataset.nav;
    if(n==="cart") openDrawer("cart");
    else if(n==="home"){ go("home"); scrollTo({top:0,behavior:REDUCED?"auto":"smooth"}); }
    else if(n==="search"){ scrollTo({top:0,behavior:REDUCED?"auto":"smooth"}); setTimeout(()=>$("#q").focus(),300); }
    else go("cats"); }
});
document.addEventListener("input",e=>{
  const id=e.target.id;
  if(id==="q"){ renderSuggest(); return; }
  if(id==="fName") form.name=e.target.value;
  if(id==="fPhone") form.phone=e.target.value;
  if(id==="fAddr") form.addr=e.target.value;
  if(id==="fNotes") form.notes=e.target.value;
  e.target.closest(".field")?.classList.remove("err");
});
document.addEventListener("submit",e=>{
  if(e.target.id!=="coForm") return; e.preventDefault();
  const bad=[]; if(!form.name.trim()) bad.push("fwName"); if(form.phone.replace(/\D/g,"").length<6) bad.push("fwPhone"); if(form.how==="ship"&&form.addr.trim().length<6) bad.push("fwAddr");
  $$(".field.err").forEach(f=>f.classList.remove("err"));
  if(bad.length){ bad.forEach(id=>$("#"+id).classList.add("err")); $("#coErr").hidden=false; $("#"+bad[0]+" input").focus(); return; }
  lastOrder=buildOrder(); drawerMode="done"; renderDrawer();
});
$("#q").addEventListener("keydown",e=>{
  const opts=$$("#suggest .sg");
  if(e.key==="ArrowDown"||e.key==="ArrowUp"){ if(!opts.length) return; e.preventDefault(); sgIdx=(sgIdx+(e.key==="ArrowDown"?1:-1)+opts.length)%opts.length; opts.forEach((o,i)=>o.setAttribute("aria-selected",String(i===sgIdx))); $("#q").setAttribute("aria-activedescendant","sg"+sgIdx); opts[sgIdx].scrollIntoView({block:"nearest"}); }
  else if(e.key==="Enter"){ e.preventDefault(); if(sgIdx>=0&&opts[sgIdx]){ closeSuggest(); openProduct(opts[sgIdx].dataset.open); } else runSearch(); }
  else if(e.key==="Escape"){ e.stopPropagation(); closeSuggest(); }
});
$("#q").addEventListener("focus",()=>{ if($("#q").value.trim()) renderSuggest(); });
document.addEventListener("pointerdown",e=>{ if(!e.target.closest("#searchBox")) closeSuggest(); });
$("#scrim").addEventListener("click",closeAll);
document.addEventListener("keydown",e=>{
  if(e.key==="Escape") closeAll();
  if(e.key==="Tab"){
    const box=$("#modal.on #modalBox")||$("#drawer.on"); if(!box) return;
    const f=[...box.querySelectorAll("button:not([disabled]),a[href],input,textarea")].filter(x=>x.offsetParent!==null&&x.tabIndex>=0);
    if(!f.length) return;
    if(e.shiftKey&&document.activeElement===f[0]){ e.preventDefault(); f[f.length-1].focus(); }
    else if(!e.shiftKey&&document.activeElement===f[f.length-1]){ e.preventDefault(); f[0].focus(); }
  }
});
let ticking=false;
let lastY=0;
const setTuck=()=>{ $("#hdr").style.setProperty("--tuck",Math.max(0,$("#searchBox").offsetTop-8)+"px"); };
addEventListener("scroll",()=>{ if(ticking) return; ticking=true; requestAnimationFrame(()=>{
  const y=scrollY, h=$("#hdr"); h.classList.toggle("scrolled",y>8);
  if(innerWidth<=640){ if(y>180 && y>lastY+4 && !$("#suggest").classList.contains("on")) h.classList.add("tuck"); else if(y<lastY-4 || y<180) h.classList.remove("tuck"); } else h.classList.remove("tuck");
  lastY=y; ticking=false; }); },{passive:true});
$("#q").addEventListener("focus",()=>$("#hdr").classList.remove("tuck"));
let rz; addEventListener("resize",()=>{ clearTimeout(rz); rz=setTimeout(()=>{ placeAll(); setTuck(); showSlide(CAR.i,true); drawGirih(); },120); });
if(document.fonts&&document.fonts.ready) document.fonts.ready.then(()=>{ placeAll(); setTuck(); });
setTuck();


if(!KR_WOO.preview){
  T.it.previewTag='Kabul Roma';T.it.previewMsg='Alimentari afghani e iraniani · Roma, Via Lamarmora 15';
  T.en.previewTag='Kabul Roma';T.en.previewMsg='Afghan and Iranian groceries · Rome, Via Lamarmora 15';
  T.fa.previewTag='کابل روما';T.fa.previewMsg='مواد غذایی افغانی و ایرانی · رم، ویا لامارمورا ۱۵';
}
applyLang(true);
krInitCart();
if(KR_WOO.product) openProduct(KR_WOO.product);

