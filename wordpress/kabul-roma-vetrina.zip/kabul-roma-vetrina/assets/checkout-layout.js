/* Move existing elements only: keep WooCommerce forms, payment fields and handlers intact. */
(function () {
  function layout() {
    var form = document.querySelector('form.checkout');
    if (!form || !form.querySelector('#customer_details')) return;
    var aside = form.querySelector('.kr-checkout-summary');
    if (!aside) {
      aside = document.createElement('div');
      aside.className = 'kr-checkout-summary';
      form.appendChild(aside);
    }
    var nodes = [form.querySelector('.wcpay-express-checkout-wrapper'), form.querySelector('#order_review_heading'), form.querySelector('#order_review'), form.querySelector('#payment'), form.querySelector('.ppc-button-wrapper')];
    nodes.forEach(function (node) { if (node && node.parentNode !== aside) aside.appendChild(node); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', layout);
  else layout();
  if (window.jQuery) window.jQuery(document.body).on('updated_checkout', layout);
})();
