<?php
defined('ABSPATH') || exit;
$cart_page = is_cart();
$complete = is_order_received_page();
$title = $cart_page ? 'Il tuo carrello' : ($complete ? 'Conferma ordine' : 'Completa il tuo ordine');
?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1">
<?php wp_head(); ?>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=Figtree:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="<?php echo esc_url(kr_asset('app.css')); ?>?v=<?php echo filemtime(__DIR__.'/assets/app.css'); ?>">
<link rel="stylesheet" href="<?php echo esc_url(kr_asset('brand.css')); ?>?v=<?php echo filemtime(__DIR__.'/assets/brand.css'); ?>">
<link rel="stylesheet" href="<?php echo esc_url(kr_asset('commerce.css')); ?>?v=<?php echo filemtime(__DIR__.'/assets/commerce.css'); ?>">
</head><body <?php body_class('kr-commerce'); ?>><?php wp_body_open(); ?>
<header class="top"><div class="wrap kr-checkout-top">
<a class="logo kr-official-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Kabul Roma"><img width="200" height="71" src="<?php echo esc_url(kr_asset('logo-kabul-roma.webp')); ?>" alt="Kabul Roma — Negozio di alimentari"></a>
<a class="kr-back" href="<?php echo esc_url($cart_page ? home_url('/') : wc_get_cart_url()); ?>"><?php echo $cart_page ? '← Continua gli acquisti' : '← Torna al carrello'; ?></a>
</div></header>
<main class="wrap kr-commerce-main" id="main">
<nav class="kr-steps" aria-label="Percorso"><a href="<?php echo esc_url(wc_get_cart_url()); ?>">Carrello</a><span aria-hidden="true">/</span><span aria-current="page"><?php echo $complete ? 'Conferma' : 'Checkout'; ?></span></nav>
<h1><?php echo esc_html($title); ?></h1>
<?php if(!$complete): ?><p class="kr-checkout-intro"><?php echo $cart_page ? 'Controlla i tuoi prodotti e prosegui con la consegna.' : 'I tuoi dati, la consegna e il pagamento. Tutto in un unico passaggio.'; ?></p><?php endif; ?>
<?php
$unavailable=array();
if(!$cart_page&&!$complete&&WC()->cart)foreach(WC()->cart->get_cart() as$key=>$item)if(!$item['data']->is_in_stock())$unavailable[$key]=$item;
if($unavailable): ?>
<section class="kr-cart-problems" role="alert"><h2>Prima di proseguire</h2><p>Questi articoli sono esauriti. Rimuovili per completare l’ordine con gli altri prodotti.</p>
<?php foreach($unavailable as$key=>$item): ?><div class="kr-unavailable-item"><?php echo $item['data']->get_image('woocommerce_thumbnail',array('width'=>64,'height'=>64,'alt'=>'')); ?><div><strong><?php echo esc_html($item['data']->get_name()); ?></strong><span>Momentaneamente esaurito</span></div><a class="button" href="<?php echo esc_url(wc_get_cart_remove_url($key)); ?>">Rimuovi e continua</a></div><?php endforeach; ?></section>
<?php else: while(have_posts()): the_post(); the_content(); endwhile; endif; ?>
</main>
<footer class="kr-commerce-footer"><div class="wrap"><span>© <?php echo esc_html(wp_date('Y')); ?> Kabul Roma S.r.l.s. · P.IVA 17586501003</span><a href="<?php echo esc_url(get_privacy_policy_url() ?: home_url('/politica-sulla-riservatezza/')); ?>">Privacy</a><a href="<?php echo esc_url(home_url('/rimborso-restituzione/')); ?>">Spedizioni e resi</a><a href="tel:+393883668516">Assistenza: +39 388 366 8516</a></div></footer>
<?php wp_footer(); ?><script defer src="<?php echo esc_url(kr_asset('checkout-layout.js')); ?>?v=<?php echo filemtime(__DIR__.'/assets/checkout-layout.js'); ?>"></script></body></html>
