<?php
defined('ABSPATH') || exit;
do_action('woocommerce_before_checkout_form', $checkout);
if (!$checkout->is_registration_enabled() && $checkout->is_registration_required() && !is_user_logged_in()) {
    echo esc_html(apply_filters('woocommerce_checkout_must_be_logged_in_message', __('You must be logged in to checkout.', 'woocommerce')));
    return;
}
?>
<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data" aria-label="Consegna e pagamento">
<div class="kr-express-area"><?php do_action('woocommerce_checkout_before_customer_details'); ?></div>
<div class="kr-checkout-grid">
<?php if($checkout->get_checkout_fields()): ?>
<section class="kr-details-card" id="customer_details" aria-label="Dati e indirizzo">
<div class="col-1"><?php do_action('woocommerce_checkout_billing'); ?></div>
<div class="col-2"><?php do_action('woocommerce_checkout_shipping'); ?></div>
<?php do_action('woocommerce_checkout_after_customer_details'); ?>
</section>
<?php endif; ?>
<aside class="kr-checkout-summary" aria-labelledby="order_review_heading">
<?php do_action('woocommerce_checkout_before_order_review_heading'); ?>
<h2 id="order_review_heading">Il tuo ordine</h2>
<?php do_action('woocommerce_checkout_before_order_review'); ?>
<div id="order_review" class="woocommerce-checkout-review-order"><?php do_action('woocommerce_checkout_order_review'); ?></div>
<?php do_action('woocommerce_checkout_after_order_review'); ?>
</aside>
</div></form>
<?php do_action('woocommerce_after_checkout_form', $checkout); ?>
