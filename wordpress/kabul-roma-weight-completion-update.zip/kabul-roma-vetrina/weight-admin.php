<?php
defined('ABSPATH') || exit;

function kr_missing_weight_products() {
    $rows = array();
    foreach (kr_seed()['prodotti'] as $index => $seed) {
        $parent = wc_get_product(kr_product_id($index, $seed));
        if (!$parent || $parent->get_status() !== 'publish') continue;
        $ids = $parent->is_type('variable') ? $parent->get_children() : array($parent->get_id());
        foreach ($ids as $id) {
            $p = wc_get_product($id);
            if (!$p || !$p->needs_shipping() || kr_poste_product_kg($p) > 0) continue;
            $rows[$id] = array('product'=>$p, 'seed'=>$seed, 'priced'=>$p->get_price() !== '');
        }
    }
    uasort($rows, function($a,$b){return (int)$b['priced'] <=> (int)$a['priced'];});
    return $rows;
}

add_action('admin_menu', function(){
    add_submenu_page('woocommerce','Pesi da completare','Pesi da completare','manage_woocommerce','kr-weights',function(){
        if (!current_user_can('manage_woocommerce')) return;
        $rows = kr_missing_weight_products();
        if (isset($_POST['kr_save_weights'])) {
            check_admin_referer('kr_save_weights');
            $changed = 0;
            foreach ((array)($_POST['kr_weight_g'] ?? array()) as $id=>$grams) {
                $id = absint($id);
                if (!isset($rows[$id]) || !current_user_can('edit_post',$id)) continue;
                $raw = trim(wp_unslash($grams));
                if ($raw === '' || !is_numeric(str_replace(',','.',$raw))) continue;
                $g = (float)wc_format_decimal($raw);
                if ($g <= 0 || $g > 100000) continue;
                $p = $rows[$id]['product'];
                $p->set_weight(wc_get_weight($g,get_option('woocommerce_weight_unit','kg'),'g'));
                $p->update_meta_data('_kr_weight_source','Peso confezione inserito dal negozio il '.current_time('Y-m-d'));
                $p->save();
                $changed++;
            }
            if ($changed) WC_Cache_Helper::get_transient_version('shipping',true);
            echo '<div class="notice notice-success"><p>'.esc_html($changed.' pesi salvati. I campi vuoti non sono stati modificati.').'</p></div>';
            $rows = kr_missing_weight_products();
        }
        $priced = count(array_filter($rows,function($r){return $r['priced'];}));
        echo '<div class="wrap"><h1>Pesi delle confezioni da completare</h1><p><strong>'.esc_html(count($rows).' prodotti senza peso, di cui '.$priced.' con prezzo.').'</strong></p><p>Pesare ogni confezione chiusa, compresi bottiglia, barattolo o sacchetto. Inserire grammi, non ml. Il peso di scatola e protezioni impostato nelle spedizioni viene aggiunto separatamente una volta per pacco. Non dedurre il peso dal volume. I prodotti senza peso non ricevono una tariffa Poste automatica.</p>';
        $page = max(1,absint($_GET['weights_page'] ?? 1));
        $pages = max(1,(int)ceil(count($rows)/40));
        $page = min($page,$pages);
        echo '<p>Pagina '.esc_html($page.' di '.$pages).'</p><form method="post">';
        wp_nonce_field('kr_save_weights');
        echo '<table class="widefat striped"><thead><tr><th>Prodotto</th><th>Stato</th><th>Peso confezione (g)</th></tr></thead><tbody>';
        foreach (array_slice($rows,($page-1)*40,40,true) as $id=>$r) {
            $p = $r['product'];
            echo '<tr><td><img src="'.esc_url(kr_asset($r['seed']['img'])).'" alt="" width="60" height="60" loading="lazy" style="object-fit:contain;vertical-align:middle;margin-right:12px"><a href="'.esc_url(get_edit_post_link($p->get_parent_id() ?: $id)).'">'.esc_html($p->get_name()).'</a></td><td>'.esc_html($r['priced']?'Con prezzo':'Senza prezzo').'</td><td><input type="number" min="0.1" max="100000" step="0.1" name="kr_weight_g['.esc_attr($id).']" aria-label="Peso confezione in grammi: '.esc_attr($p->get_name()).'" placeholder="Da pesare"></td></tr>';
        }
        echo '</tbody></table>';
        submit_button('Salva i pesi inseriti','primary','kr_save_weights');
        echo '</form><p>';
        for($n=1;$n<=$pages;$n++) echo '<a class="button" style="margin-right:8px" href="'.esc_url(admin_url('admin.php?page=kr-weights&weights_page='.$n)).'">'.esc_html($n).'</a>';
        echo '</p></div>';
    });
});
