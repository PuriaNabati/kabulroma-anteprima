<?php
defined('ABSPATH') || exit;
do_action('woocommerce_before_checkout_form', $checkout);
if (!$checkout->is_registration_enabled() && $checkout->is_registration_required() && !is_user_logged_in()) {
    echo esc_html(apply_filters('woocommerce_checkout_must_be_logged_in_message', __('You must be logged in to checkout.', 'woocommerce')));
    return;
}
?>
<form name="checkout" method="post" class="checkout woocommerce-checkout" action="<?php echo esc_url(wc_get_checkout_url()); ?>" enctype="multipart/form-data" aria-label="Consegna e pagamento">
<div class="kr-checkout-grid">
<aside class="kr-checkout-summary" aria-label="Riepilogo ordine">
<details class="kr-summary-details" open>
<summary class="kr-summary-toggle"><span><span class="kr-summary-label">Il tuo ordine</span><small class="kr-summary-hint">Prodotti e spedizione <span aria-hidden="true">⌄</span></small></span><strong class="kr-summary-total" aria-live="polite"><?php echo wp_kses_post(WC()->cart->get_total()); ?></strong></summary>
<div class="kr-summary-content">
<?php do_action('woocommerce_checkout_before_order_review_heading'); ?>
<h2 id="order_review_heading" class="screen-reader-text">Riepilogo prodotti e costi</h2>
<?php do_action('woocommerce_checkout_before_order_review'); ?>
<div id="order_review" class="woocommerce-checkout-review-order"><?php do_action('woocommerce_checkout_order_review'); ?></div>
<?php do_action('woocommerce_checkout_after_order_review'); ?>
</div></details></aside>
<div class="kr-checkout-main">
<div class="kr-express-area"><?php do_action('woocommerce_checkout_before_customer_details'); ?></div>
<?php if($checkout->get_checkout_fields()): ?>
<section id="customer_details" aria-label="Contatti e consegna">
<div class="col-1"><?php do_action('woocommerce_checkout_billing'); ?></div>
<div class="col-2"><?php do_action('woocommerce_checkout_shipping'); ?></div>
<?php do_action('woocommerce_checkout_after_customer_details'); ?>
</section>
<?php endif; ?>
<section class="kr-payment-section" aria-labelledby="kr-payment-heading"><h2 id="kr-payment-heading">Pagamento</h2>
<?php woocommerce_checkout_payment(); ?>
</section>
</div></div></form>
<?php do_action('woocommerce_after_checkout_form', $checkout); ?>
