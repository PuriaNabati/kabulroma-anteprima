/* Native WooCommerce owns totals, validation and payment. */
(function(){
function optionalFields(){
 var form=document.querySelector('form.checkout');if(!form)return;
 var fields=form.querySelector('.woocommerce-billing-fields__field-wrapper');
 if(fields&&!fields.querySelector('.kr-optional-address')){
  var rows=['billing_address_2_field','billing_company_field'].map(function(id){return document.getElementById(id);}).filter(function(row){return row&&!row.classList.contains('validate-required');});
  if(rows.length){var details=document.createElement('details');details.className='kr-optional-address';var summary=document.createElement('summary');summary.textContent='Interno, citofono o azienda (facoltativo)';details.appendChild(summary);rows.forEach(function(row){details.appendChild(row);});fields.appendChild(details);}
 }
 if(fields){var country=document.getElementById('billing_country_field');var title=fields.querySelector('.kr-address-title');if(country&&title)fields.insertBefore(title,country);var optional=fields.querySelector('.kr-optional-address');if(optional)fields.appendChild(optional);}
 var notes=form.querySelector('.woocommerce-additional-fields');
 if(notes&&!notes.querySelector('details')&&notes.querySelector('textarea')){var group=notes.querySelector('.woocommerce-additional-fields__field-wrapper');if(group){var detail=document.createElement('details');detail.className='kr-optional-notes';var title=document.createElement('summary');title.textContent='Aggiungi una nota per la consegna';detail.appendChild(title);detail.appendChild(group);var heading=notes.querySelector('h3');if(heading)heading.hidden=true;notes.appendChild(detail);}}
}
var timer;function refresh(){clearTimeout(timer);timer=setTimeout(function(){if(window.jQuery)window.jQuery(document.body).trigger('update_checkout');},220);}
document.addEventListener('click',function(event){var button=event.target.closest('[data-kr-qty]');if(!button)return;var input=button.parentNode.querySelector('input');if(!input)return;var next=Math.max(Number(input.min)||1,Math.min(Number(input.max)||99,(Number(input.value)||1)+Number(button.dataset.krQty)));if(next!==Number(input.value)){input.value=next;refresh();}});
document.addEventListener('change',function(event){if(event.target.matches('.kr-checkout-qty'))refresh();});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',optionalFields);else optionalFields();
if(window.jQuery)window.jQuery(document.body).on('updated_checkout',optionalFields);
})();
